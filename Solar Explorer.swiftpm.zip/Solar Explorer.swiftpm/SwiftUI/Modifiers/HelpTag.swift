//
//  HelpTag.swift
//  Solar Explorer
//
//  Zachary Lineman
//

import SwiftUI

extension View {
    func helpTag<Content: View>(enabled: Bool, color: Color = Color(uiColor: .secondarySystemBackground), offset: CGSize = CGSize.zero, @ViewBuilder content: () -> Content,  didClick: @escaping () -> Void) -> some View {
        if !enabled {
            return AnyView(self)
        } else {
            return AnyView(
            self
                .disabled(true)
                .shadow(color: Color.white, radius: 7)
                .shadow(color: Color.white, radius: 7)
                .shadow(color: Color.white, radius: 7)
                .overlay {
                    ZStack {
                        Rectangle()
                            .fill(.black.opacity(0.01))
                            .frame(width: UIScreen.main.bounds.width * 2, height: UIScreen.main.bounds.height * 2)
                            .position()
                        content()
                            .padding(20)
                            .background(color)
                            .cornerRadius(20)
                            .offset(offset)
                    }
                }
                .onTapGesture {
                    didClick()
                }
            )
        }
    }
}
