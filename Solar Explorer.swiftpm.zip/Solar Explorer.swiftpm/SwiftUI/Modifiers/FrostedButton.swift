//
//  FrostedButton.swift
//  Solar Explorer
//
//  Created by Zachary lineman
//

import SwiftUI

// A button that appears slightly frosted. Basically just a white tinted button.
struct FrostedButton: ViewModifier {
    var activated: Bool
    var activationColor: Color
    
    func body(content: Content) -> some View {
        content
            .background(activated ? activationColor : Color.white.opacity(0.3))
            .cornerRadius(7)
            .shadow(color: .black.opacity(0.6), radius: 5, x: 0, y: 0)
    }
}

extension View {
    // A view modifier that makes the current view appear like a frosted button.
    func frostedButton(activated: Bool = false, color: Color = Color.white.opacity(0.3)) -> some View {
        return self
            .frame(width: 65, height: 45)
            .modifier(FrostedButton(activated: activated, activationColor: color))       
        
    }
    
    // A view modifier that removes the activation color switching and just makes the view frosted.
    func frosted() -> some View {
        return self.modifier(FrostedButton(activated: false, activationColor: .white))
    }
}
