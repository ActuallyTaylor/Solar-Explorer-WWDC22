//
//  PlanetaryStats.swift
//  Solar Explorer
//
//  Created by Zachary lineman
//

import SwiftUI

// This view shows the stats for the ecosystem simulation.
struct EcosystemStats: View {
    @EnvironmentObject var universe: Universe

    var body: some View {
        VStack(alignment: .leading) {
            Text("FPS: \(universe.fps)")
                .font(.system(.body, design: .rounded))
            Text("Creature Count: \(universe.currentlyExploringPlanet.creatures.count)")
                .font(.system(.body, design: .rounded))
            Text("World Item Count: \(universe.currentlyExploringPlanet.world.count)")
                .font(.system(.body, design: .rounded))

            Text("Current Simulation Step: \(universe.currentlyExploringPlanet.currentEcosystemStep)")
                .font(.system(.body, design: .rounded))
            Text("Total Elements: \(universe.totalElementCount())")
                .font(.system(.body, design: .rounded))
        }
        .padding()
        .frosted()
        .padding()
        .padding(.top, 30)
        .opacity(universe.shouldShowStats ? 1 : 0)
    }
}
