//
//  PlanetaryControlStrip.swift
//  Solar Explorer
//
//  Created by Zachary lineman
//

import SwiftUI

// This is the view for the ecosystem control strip.
struct EcosystemControlStrip: View {
    @EnvironmentObject var universe: Universe
    var reader: GeometryProxy
    
    @State var pauseUnpause: Bool = false
    @State var exit: Bool = false

    var body: some View {
        HStack(alignment: .center) {
            Spacer()
            VStack {
                // Play / Pause
                Button {
                    withAnimation {
                        pauseUnpause = true
                    }
                    universe.currentlyExploringPlanet.shouldSimulateEcosystem.toggle()
                    Dispatch.delay(seconds: 0.2) {
                        withAnimation {
                            pauseUnpause = false
                        }
                    }
                } label: {
                    Image(systemName: universe.currentlyExploringPlanet.shouldSimulateEcosystem ? "pause.circle" : "play.circle")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .foregroundColor(.white)
                        .padding(5)
                        .frame(height: 45)
                }
                .frostedButton(activated: pauseUnpause, color: Color.blue.opacity(0.6))
                .disabled(universe.isEditingPlanet)
                
                // Stats
                Button {
                    withAnimation {
                        universe.shouldShowStats.toggle()
                    }
                } label: {
                    Text("STATS")
                        .font(.system(.body, design: .rounded))
                        .foregroundColor(.white)
                }
                .frostedButton(activated: universe.shouldShowStats, color: Color.green.opacity(0.6))
                .disabled(universe.isEditingPlanet)
                
                // Exit
                Button {
                    withAnimation {
                        exit = true
                        universe.stopExploring()
                    }
                    Dispatch.delay(seconds: 0.2) {
                        withAnimation {
                            exit = false
                        }
                    }
                } label: {
                    Text("EXIT")
                        .font(.system(.body, design: .rounded))
                        .foregroundColor(.white)
                }
                .frostedButton(activated: exit, color: Color.blue.opacity(0.6))

            }
            .padding(7)
            .background(Color(uiColor: .secondarySystemBackground).opacity(0.8))
            .cornerRadius(7)
            .padding(.trailing, 5)
        }
        .frame(height: reader.size.height)
    }
}
