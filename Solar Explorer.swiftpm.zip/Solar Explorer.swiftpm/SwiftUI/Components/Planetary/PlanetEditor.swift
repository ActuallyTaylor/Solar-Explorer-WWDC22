//
//  PlanetEditor.swift
//  Solar Explorer
//
//  Created by Zachary lineman
//

import SwiftUI

// This view allows you to either edit a planet or create a new planet. Because they are both very similar activities, their views can be combined.
struct PlanetEditor: View {
    @EnvironmentObject var universe: Universe
    var reader: GeometryProxy
    @State var deletePrompt: Bool = false

    var body: some View {
        VStack {
            // MARK: Top Section
            Text(universe.isAddingPlanet ? "Planet Creator" : "Planet Editor")
                .font(.system(.title2, design: .rounded))
                .fontWeight(.bold)
                .foregroundColor(Color(UIColor.label))
                .padding([.top], 30)
            HStack(alignment: .center, spacing: 0) {
                Text("Planet Name:")
                    .font(.system(.body, design: .rounded))
                    .fontWeight(.semibold)
                TextField("Planet Name", text: $universe.editingPlanetName)
                    .font(.system(.body, design: .rounded))
                    .foregroundColor(Color(UIColor.label))
                    .padding(.leading, 10)
                    .onChange(of: universe.editingPlanetName) { _ in
                        universe.updateEditingPlanetData()
                    }
            }
            .padding(.leading, 10)
            .helpTag(enabled: HelpController.shared.isEnabled("Name"), color: Color(uiColor: .systemGray5)) {
                VStack {
                    Text("Planet Name")
                        .font(.system(size: 24, weight: .bold, design: .rounded))
                    Text("This is the name that represents the planet. Changing this is purely cosmetic.")
                        .font(.system(size: 16, weight: .regular, design: .rounded))
                }
                .frame(width: 300, height: 75)
            } didClick: {
                HelpController.shared.advanceHelpView(track: .editor)
            }

            // MARK: Lower Section
            HStack(alignment: .center, spacing: 0) {
                Text("Velocity:\t")
                    .font(.system(.body, design: .rounded))
                    .fontWeight(.semibold)
                Text("X: ")
                    .font(.system(.body, design: .rounded))
                TextField("X", value: $universe.editingPlanetVelocityX, format: .number)
                    .font(.system(.body, design: .rounded))
                    .foregroundColor(Color(UIColor.label))
                    .padding(.leading, 10)
                    .frame(width: 160)
                    .onChange(of: universe.editingPlanetVelocityX) { _ in
                        universe.resetFuturePhysics()
                        universe.updateEditingPlanetData()
                        universe.simulatePhysicsIntoFuture(steps: universe.futurePhysicsCalculation)
                    }
                Text("Y: ")
                    .font(.system(.body, design: .rounded))
                TextField("Y", value: $universe.editingPlanetVelocityY, format: .number)
                    .font(.system(.body, design: .rounded))
                    .foregroundColor(Color(UIColor.label))
                    .padding(.leading, 10)
                    .frame(width: 160)
                    .onChange(of: universe.editingPlanetVelocityY) { _ in
                        universe.resetFuturePhysics()
                        universe.updateEditingPlanetData()
                        universe.simulatePhysicsIntoFuture(steps: universe.futurePhysicsCalculation)
                    }
                Spacer()
            }
            .padding(.leading, 10)
            .helpTag(enabled: HelpController.shared.isEnabled("Velocity"), color: Color(uiColor: .systemGray5)) {
                VStack {
                    Text("Planet Velocity")
                        .font(.system(size: 24, weight: .bold, design: .rounded))
                    Text("Changing the planet's velocity will effect the direction that the planet moves. Changes here will change the instantaneous velocity of the planet. This can be used change the orbit of a planet.")
                        .font(.system(size: 16, weight: .regular, design: .rounded))
                }
                .frame(width: 300, height: 125)
            } didClick: {
                HelpController.shared.advanceHelpView(track: .editor)
            }

            HStack(alignment: .center, spacing: 0) {
                Text("Mass:")
                    .font(.system(.body, design: .rounded))
                    .fontWeight(.semibold)
                TextField("Mass", value: $universe.editingPlanetMass, format: .number)
                    .font(.system(.body, design: .rounded))
                    .foregroundColor(Color(UIColor.label))
                    .padding(.leading, 10)
                    .onChange(of: universe.editingPlanetMass) { _ in
                        universe.resetFuturePhysics()
                        universe.updateEditingPlanetData()
                        universe.simulatePhysicsIntoFuture(steps: universe.futurePhysicsCalculation)
                    }
            }
            .padding(.leading, 10)
            .helpTag(enabled: HelpController.shared.isEnabled("Mass"), color: Color(uiColor: .systemGray5), offset: CGSize(width: 0, height: -25)) {
                VStack {
                    Text("Planet Mass")
                        .font(.system(size: 24, weight: .bold, design: .rounded))
                    Text("Changing the planet's mass will effect how other planets are attracted to it. A high mass means other planets will be pulled toward it.")
                        .font(.system(size: 16, weight: .regular, design: .rounded))
                }
                .frame(width: 300, height: 125)
            } didClick: {
                HelpController.shared.advanceHelpView(track: .editor)
            }

            HStack(alignment: .center, spacing: 0) {
                Text("Radius:")
                    .fontWeight(.semibold)
                TextField("Radius", value: $universe.editingPlanetRadius, format: .number)
                    .foregroundColor(Color(UIColor.label))
                    .padding(.leading, 10)
                    .onChange(of: universe.editingPlanetRadius) { _ in
                        universe.resetFuturePhysics()
                        universe.updateEditingPlanetData()
                        universe.simulatePhysicsIntoFuture(steps: universe.futurePhysicsCalculation)
                    }
            }
            .padding(.leading, 10)
            .helpTag(enabled: HelpController.shared.isEnabled("Radius"), color: Color(uiColor: .systemGray5), offset: CGSize(width: 0, height: -65)) {
                VStack {
                    Text("Planet Radius")
                        .font(.system(size: 24, weight: .bold, design: .rounded))
                    Text("Changing the planet's radius will change how large it appears on the canvas.")
                        .font(.system(size: 16, weight: .regular, design: .rounded))
                }
                .frame(width: 300, height: 100)
            } didClick: {
                HelpController.shared.advanceHelpView(track: .editor)
            }

            HStack {
                Button {
                    universe.submitPlanetUpdates()
                    UIApplication.shared.endEditing()
                } label: {
                    Text("Finish Planet")
                        .font(.system(.body, design: .rounded))
                        .foregroundColor(.white)
                        .padding(10)
                        .background(Color(uiColor: UIColor.link))
                        .cornerRadius(10)
                }
                .padding(.bottom, 10)
                if !universe.isAddingPlanet {
                    Button {
                        universe.cancelPlanet()
                        UIApplication.shared.endEditing()
                    } label: {
                        Text("Cancel")
                            .font(.system(.body, design: .rounded))
                            .foregroundColor(.white)
                            .padding(10)
                            .background(.yellow)
                            .cornerRadius(10)
                    }
                    .padding(.bottom, 10)
                }
                Button {
                    deletePrompt.toggle()
                } label: {
                    Text("Delete")
                        .font(.system(.body, design: .rounded))
                        .foregroundColor(.white)
                        .padding(10)
                        .background(.red)
                        .cornerRadius(10)
                }
                .padding(.bottom, 10)
                .alert("Are you sure?", isPresented: $deletePrompt, actions: {
                    Button("Cancel", role: .cancel) { }
                    Button("Delete", role: .destructive) {
                        universe.deletePlanet()
                        UIApplication.shared.endEditing()
                    }
                }, message: {
                    Text("This action is irreversible")
                })
            }
        }
        .frame(width: reader.size.width, alignment: .topLeading)
        .background(Color(UIColor.secondarySystemBackground))
        .cornerRadius(20)
        .opacity(universe.shouldShowPlanetTool ? 1 : 0)
        .offset(y: universe.shouldShowPlanetTool ? 0 : -300)
    }
}
