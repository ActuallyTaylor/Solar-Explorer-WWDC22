//
//  PlanetaryBodies.swift
//  Solar Explorer
//
//  Created by Zachary lineman
//

import SwiftUI
import UIKit

// This is the view that shows a list of planetary bodies.
struct PlanetaryBodies: View {
    @EnvironmentObject var universe: Universe
    var reader: GeometryProxy

    var body: some View {
        ZStack {
            VStack {
                Text("Planetary Bodies")
                    .font(.system(.title, design: .rounded))
                    .fontWeight(.bold)
                    .foregroundColor(Color(UIColor.label))
                    .padding([.top, .leading])
                ForEach(universe.bodies, id: \.self.id) { body in
                    HStack {
                        Circle()
                            .fill(Color(uiColor: body.color))
                            .frame(width: 45, height: 45)
                        VStack(alignment: .leading) {
                            Text(body.name == "" ? "No Planet Name" : body.name)
                                .font(.system(.body, design: .rounded))
                            Text(body.id.uuidString)
                                .font(.system(.body, design: .rounded))
                                .foregroundColor(.secondary)
                        }
                        Spacer()
                    }
                    .padding([.leading, .trailing], 20)
                    .frame(width: reader.size.width - 200, height: 88)
                    .background(Color(uiColor: .systemGray5))
                    .cornerRadius(7)
                    .onTapGesture {
                        withAnimation {
                            universe.shouldShowBodiesPanel = false
                            universe.mainScene.focusToPlanet(body)
                        }
                    }
                }
                Spacer()
            }
            .frame(width: reader.size.width - 100, height: reader.size.height - 100)
            .background(Color(UIColor.secondarySystemBackground))
            .cornerRadius(20)
            VStack {
                HStack {
                    Spacer()
                    Button {
                        withAnimation {
                            universe.shouldShowBodiesPanel = false
                        }
                    } label: {
                        Image(systemName: "xmark.circle.fill")
                            .resizable()
                            .foregroundColor(.secondary)
                            .frame(width: 25, height: 25)
                            .padding(10)
                    }
                }
                Spacer()
            }
            .frame(width: reader.size.width - 100, height: reader.size.height - 100)
        }
        .frame(width: reader.size.width, height: reader.size.height, alignment: Alignment(horizontal: .center, vertical: .center))
        .opacity(universe.shouldShowBodiesPanel ? 1 : 0)
    }
}
