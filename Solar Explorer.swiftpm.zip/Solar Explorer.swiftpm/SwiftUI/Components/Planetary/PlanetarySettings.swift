//
//  File.swift
//  Solar Explorer
//
//  Created by Zachary lineman.
//

import Foundation
import SwiftUI

// This is the view that shows a list of planetary bodies.
struct PlanetarySettings: View {
    @EnvironmentObject var universe: Universe
    var reader: GeometryProxy
    
    var ratioProxy: Binding<Double>{
        Binding<Double>(get: {
            return Double(universe.ecosystemStepToPhysicsStepRatio)
        }, set: {
            universe.ecosystemStepToPhysicsStepRatio = Int($0)
        })
    }
    
    var lengthProxy: Binding<Double>{
        Binding<Double>(get: {
            return Double(universe.trailLength)
        }, set: {
            universe.trailLength = Int($0)
        })
    }

    var body: some View {
        ZStack {
            VStack {
                Text("Settings")
                    .font(.system(.title, design: .rounded))
                    .fontWeight(.bold)
                    .foregroundColor(Color(UIColor.label))
                    .padding([.top, .leading])
                
                // Settings
                ScrollView {
                    // Toggle for background simulation of ecosystems
                    Toggle(isOn: $universe.shouldSimulateEcosystemsInBackground) {
                        VStack(alignment: .leading) {
                            Text("Background Ecosystem Simulation")
                                .font(.system(.title3, design: .rounded))
                            Group {
                                Text("Turning this on will start simulating all ecosystems in the universe at once in the background. ")
                                    .foregroundColor(.secondary) +
                                Text("This is very resource intensive and may slow down the simulation.")
                                    .foregroundColor(.red)
                            }
                                .font(.system(size: 12, weight: .regular, design: .rounded))
                        }
                    }
                    .padding(10)
                    
                    // Planetary Step to Ecosystem Ration slider
                    VStack {
                        HStack {
                            Text("Planetary Step -> Ecosystem Step Ratio (\(universe.ecosystemStepToPhysicsStepRatio))")
                                .font(.system(.title3, design: .rounded))
                            Spacer()
                        }
                        HStack {
                            Text("Changing this will effect how long it takes to load the ecosystem simulation. A larger step will be faster, a smaller step will be slower.")
                                .foregroundColor(.secondary)
                                .font(.system(size: 12, weight: .regular, design: .rounded))
                            Spacer()
                        }
                        Slider(value: ratioProxy, in: 1...20) {
                            Text("\(ratioProxy.wrappedValue)")
                        } minimumValueLabel: {
                            Text("0")
                                .font(.system(.body, design: .rounded))
                        } maximumValueLabel: {
                            Text("20")
                                .font(.system(.body, design: .rounded))
                        }
                    }
                    .frame(alignment: .leading)
                    .padding(10)
                    
                    // Slider for planetary trail lengths.
                    VStack {
                        HStack {
                            Text("Planet Trail Length (\(universe.trailLength))")
                                .font(.system(.title3, design: .rounded))
                            Spacer()
                        }
                        HStack {
                            Text("Having a higher trail length can cause slowdowns.")
                                .foregroundColor(.secondary)
                                .font(.system(size: 12, weight: .regular, design: .rounded))
                            Spacer()
                        }
                        Slider(value: lengthProxy, in: 0...2000) {
                            Text("\(lengthProxy.wrappedValue)")
                        } minimumValueLabel: {
                            Text("0")
                                .font(.system(.body, design: .rounded))
                        } maximumValueLabel: {
                            Text("2000")
                                .font(.system(.body, design: .rounded))
                        }
                    }
                    .frame(alignment: .leading)
                    .padding(10)

                }
                Spacer()
            }
            .frame(width: reader.size.width - 300, height: reader.size.height - 300)
            .background(Color(UIColor.secondarySystemBackground))
            .cornerRadius(20)
            VStack {
                HStack {
                    Spacer()
                    Button {
                        withAnimation {
                            universe.shouldShowSettings = false
                        }
                    } label: {
                        Image(systemName: "xmark.circle.fill")
                            .resizable()
                            .foregroundColor(.secondary)
                            .frame(width: 25, height: 25)
                            .padding(10)
                    }
                }
                Spacer()
            }
            .frame(width: reader.size.width - 300, height: reader.size.height - 300)
        }
        .frame(width: reader.size.width, height: reader.size.height, alignment: Alignment(horizontal: .center, vertical: .center))
        .opacity(universe.shouldShowSettings ? 1 : 0)
    }
}
