//
//  PlanetaryStats.swift
//  Solar Explorer
//
//  Created by Zachary lineman
//

import SwiftUI

// This view shows all of the stats for the universe simulation.
struct PlanetaryStats: View {
    @EnvironmentObject var universe: Universe

    var body: some View {
        VStack(alignment: .leading) {
            Text("FPS: \(universe.fps)")
                .font(.system(.body, design: .rounded))
            Text("Planet Count: \(universe.bodies.count)")
                .font(.system(.body, design: .rounded))
            Text("Current Physics Step: \(universe.currentPhysicsStep)")
                .font(.system(.body, design: .rounded))
            Text("Furthest Calculated Step: \(universe.farthestCalculation)")
                .font(.system(.body, design: .rounded))
            Text("Total Elements: \(universe.totalElementCount())")
                .font(.system(.body, design: .rounded))
        }
        .padding()
        .frosted()
        .padding()
        .padding(.top, 30)
        .opacity(universe.shouldShowStats ? 1 : 0)
    }
}
