//
//  PlanetaryControlStrip.swift
//  Solar Explorer
//
//  Created by Zachary lineman
//

import SwiftUI

// This is the control strip / side bar for the universe simulation.
struct PlanetaryControlStrip: View {
    @EnvironmentObject var universe: Universe
    @StateObject var helpController: HelpController = HelpController.shared
    
    var reader: GeometryProxy
    
    @State var pauseUnpause: Bool = false
    @State var reset: Bool = false
    
    
    var body: some View {
        HStack(alignment: .center) {
            Spacer()
            VStack {
                // Play / Pause
                Button {
                    if !universe.isEditingPlanet {
                        withAnimation {
                            pauseUnpause = true
                        }
                        universe.planetSimRunning.toggle()
                        Dispatch.delay(seconds: 0.2) {
                            withAnimation {
                                pauseUnpause = false
                            }
                        }
                    }
                } label: {
                    Image(systemName: universe.planetSimRunning ? "pause.circle" : "play.circle")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .foregroundColor(.white)
                        .padding(5)
                        .frame(height: 45)
                }
                .frostedButton(activated: pauseUnpause, color: Color.blue.opacity(0.6))
                .disabled(universe.isEditingPlanet)
                
                // Reset
                Button {
                    if !universe.isEditingPlanet {
                        withAnimation {
                            reset = true
                        }
                        universe.resetSim()
                        Dispatch.delay(seconds: 0.2) {
                            withAnimation {
                                reset = false
                            }
                        }
                    }
                } label: {
                    Image(systemName: "arrow.triangle.2.circlepath.circle")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .foregroundColor(.white)
                        .padding(5)
                        .frame(height: 45)
                }
                .frostedButton(activated: reset, color: Color.blue.opacity(0.6))
                .disabled(universe.isEditingPlanet)
                
                // Enable / Disable trails
                Button {
                    withAnimation {
                        universe.shouldShowTrails.toggle()
                    }
                } label: {
                    Text("TRAILS")
                        .font(.system(.body, design: .rounded))
                        .foregroundColor(.white)
                }
                .frostedButton(activated: universe.shouldShowTrails, color: Color.green.opacity(0.6))
                
                // Enable / Disable Stats view
                Button {
                    withAnimation {
                        universe.shouldShowStats.toggle()
                    }
                } label: {
                    Text("STATS")
                        .font(.system(.body, design: .rounded))
                        .foregroundColor(.white)
                }
                .frostedButton(activated: universe.shouldShowStats, color: Color.green.opacity(0.6))
                .disabled(universe.isEditingPlanet)
                
                // Enable / Disable bodies view
                Button {
                    withAnimation {
                        universe.shouldShowBodiesPanel.toggle()
                        
                        if universe.shouldShowBodiesPanel {
                            universe.shouldShowSettings = false
                        }
                    }
                } label: {
                    Text("BODIES")
                        .font(.system(.body, design: .rounded))
                        .foregroundColor(.white)
                }
                .frostedButton(activated: universe.shouldShowBodiesPanel, color: Color.green.opacity(0.6))
                
                // Enable / Disable background simulation of ecosystems
                Button {
                    withAnimation {
                        universe.shouldShowSettings.toggle()
                        
                        if universe.shouldShowSettings {
                            universe.shouldShowBodiesPanel = false
                        }
                    }
                } label: {
                    Image(systemName: "gear")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .foregroundColor(.white)
                        .padding(5)
                        .frame(height: 45)
                }
                .frame(width: 65, height: 100)
                .frostedButton(activated: universe.shouldShowSettings, color: Color.green.opacity(0.6))
                
                // Enable / Disable background simulation of ecosystems
                Button {
                    withAnimation {
                        withAnimation {
                            helpController.currentHelpView = helpController.startingTags[0]
                        }
                    }
                } label: {
                    Image(systemName: "questionmark.circle")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .foregroundColor(.white)
                        .padding(5)
                        .frame(height: 45)
                }
                .frame(width: 65, height: 100)
                .frostedButton(activated: universe.shouldShowSettings, color: Color.green.opacity(0.6))
            }
            .padding(7)
            .background(Color(uiColor: .secondarySystemBackground).opacity(0.8))
            .cornerRadius(7)
            .padding(.trailing, 5)
            .helpTag(enabled: helpController.isEnabled("Control Strip"), offset: CGSize(width: -320, height: 0)) {
                VStack {
                    Text("Control Strip")
                        .font(.system(size: 24, weight: .bold, design: .rounded))
                    Text("The control Strip allows you to change different aspects of the simulation.")
                        .font(.system(size: 16, weight: .regular, design: .rounded))
                    
                    VStack(alignment: .leading) {
                        // Play Button Description
                        HStack {
                            Image(systemName: universe.planetSimRunning ? "pause.circle" : "play.circle")
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .foregroundColor(.white)
                                .padding(5)
                                .frame(height: 45)
                                .frostedButton(activated: pauseUnpause, color: Color.blue.opacity(0.6))
                            VStack(alignment: .leading) {
                                Text("Play Button")
                                    .font(.system(size: 16, weight: .bold, design: .rounded))
                                Text("This button allows you to play and pause the simulation.")
                                    .font(.system(size: 13, weight: .regular, design: .rounded))
                                    .fixedSize(horizontal: false, vertical: true)
                            }
                        }
                        
                        // Reset Button Description
                        HStack {
                            Image(systemName: "arrow.triangle.2.circlepath.circle")
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .foregroundColor(.white)
                                .padding(5)
                                .frame(height: 45)
                                .frostedButton(activated: pauseUnpause, color: Color.blue.opacity(0.6))
                            VStack(alignment: .leading) {
                                Text("Reset Button")
                                    .font(.system(size: 16, weight: .bold, design: .rounded))
                                Text("This button will reset the entire simulation back to the starting state.")
                                    .font(.system(size: 13, weight: .regular, design: .rounded))
                                    .fixedSize(horizontal: false, vertical: true)
                            }
                        }
                        
                        // Trails Button Description
                        HStack {
                            Text("TRAILS")
                                .font(.system(.body, design: .rounded))
                                .foregroundColor(.white)
                                .frostedButton(activated: pauseUnpause, color: Color.blue.opacity(0.6))
                            VStack(alignment: .leading) {
                                Text("Trails Setting")
                                    .font(.system(size: 16, weight: .bold, design: .rounded))
                                Text("This setting disables or enables visual trails of the planets.")
                                    .font(.system(size: 13, weight: .regular, design: .rounded))
                                    .fixedSize(horizontal: false, vertical: true)

                            }
                        }
                        
                        // Trails Button Description
                        HStack {
                            Text("STATS")
                                .font(.system(.body, design: .rounded))
                                .foregroundColor(.white)
                                .frostedButton(activated: pauseUnpause, color: Color.blue.opacity(0.6))
                            VStack(alignment: .leading) {
                                Text("Stats Toggle")
                                    .font(.system(size: 16, weight: .bold, design: .rounded))
                                Text("Selecting this toggle will enable the stats view. This view gives statistics for the simulation & the scene.")
                                    .font(.system(size: 13, weight: .regular, design: .rounded))
                                    .fixedSize(horizontal: false, vertical: true)

                            }
                        }
                        
                        // Bodies View Description
                        HStack {
                            Text("BODIES")
                                .font(.system(.body, design: .rounded))
                                .foregroundColor(.white)
                                .frostedButton(activated: pauseUnpause, color: Color.blue.opacity(0.6))
                            VStack(alignment: .leading) {
                                Text("Bodies View")
                                    .font(.system(size: 16, weight: .bold, design: .rounded))
                                Text("Clicking on this button will toggle the bodies view. This view allows you to see all of the current planets in the simulation.")
                                    .font(.system(size: 13, weight: .regular, design: .rounded))
                                    .fixedSize(horizontal: false, vertical: true)

                            }
                        }
                        
                        HStack {
                            Image(systemName: "gear")
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .foregroundColor(.white)
                                .padding(5)
                                .frame(height: 45)
                                .frostedButton(activated: pauseUnpause, color: Color.blue.opacity(0.6))
                            VStack(alignment: .leading) {
                                Text("Settings View")
                                    .font(.system(size: 16, weight: .bold, design: .rounded))
                                Text("This button will toggle the simulation settings. Simulation settings can be used to tailor your experience.")
                                    .font(.system(size: 13, weight: .regular, design: .rounded))
                                    .fixedSize(horizontal: false, vertical: true)

                            }
                        }
                        
                        HStack {
                            Image(systemName: "questionmark.circle")
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .foregroundColor(.white)
                                .padding(5)
                                .frame(height: 45)
                                .frostedButton(activated: pauseUnpause, color: Color.blue.opacity(0.6))
                            VStack(alignment: .leading) {
                                Text("Help Button")
                                    .font(.system(size: 16, weight: .bold, design: .rounded))
                                Text("The help button will restart this tutorial.")
                                    .font(.system(size: 13, weight: .regular, design: .rounded))
                                    .fixedSize(horizontal: false, vertical: true)

                            }
                        }
                        
                    }
                    
                }
                .frame(width: 300)
            } didClick: {
                helpController.advanceHelpView(track: .starting)
            }
            
        }
        .frame(height: reader.size.height)
    }
}
