//
//  PlanetarySimulation.swift
//  Solar Explorer
//
//  Created by Zachary lineman
//

import SwiftUI
import UIKit
import SpriteKit

// The only view for the entire app. Multiple views are not necessary so it just swaps between what is on screen when it is needed.
struct PlanetarySimulation: View {
    // Universe object that gets passed to almost every subview and scene.
    @StateObject var universe: Universe = Universe()

    // MARK: Sprite Kit scenes
    let planetScene = PlanetScene()
    let simulationScene = EcosystemScene()
    let waitingScene = WaitingScene()
    
    var body: some View {
        GeometryReader { reader in
            ZStack(alignment: Alignment(horizontal: .leading, vertical: .top)) {
                // Check to see if we should display the waiting view
                if universe.waitingForSync {
                    SpriteView(scene: waitingScene)
                        .ignoresSafeArea()
                } else {
                    // Check to see if we are currently exploring a planet or not. If so show the planet view, if not show the universe view.
                    if !universe.currentlyExploring {
                        SpriteView(scene: planetScene)
                            .ignoresSafeArea()
                            .helpTag(enabled: HelpController.shared.isEnabled("Start")) {
                                VStack {
                                    Text("Welcome to Solar Explorer!")
                                        .font(.system(size: 24, weight: .bold, design: .rounded))
                                    Text("This is an app that allows you to explore your own custom universes!")
                                        .font(.system(size: 16, weight: .regular, design: .rounded))
                                    
                                    HStack {
                                        Image(systemName: "ipad.landscape")
                                            .resizable()
                                            .aspectRatio(contentMode: .fit)
                                            .foregroundColor(.white)
                                            .padding(5)
                                            .frame(height: 55)
                                        VStack(alignment: .leading) {
                                            Text("Put your iPad in landscape")
                                                .font(.system(size: 16, weight: .bold, design: .rounded))
                                            Text("This experience works best in landscape mode")
                                                .font(.system(size: 13, weight: .regular, design: .rounded))
                                        }
                                        Spacer()
                                    }

                                    
                                    HStack {
                                        Image(systemName: "moon.stars")
                                            .resizable()
                                            .aspectRatio(contentMode: .fit)
                                            .foregroundColor(.white)
                                            .padding(5)
                                            .frame(height: 55)
                                        VStack(alignment: .leading) {
                                            Text("Dark Mode")
                                                .font(.system(size: 16, weight: .bold, design: .rounded))
                                            Text("Please put your iPad into dark mode. Some colors may not appear correctly, everything will work in light mode but for the best experience dark mode is recommended.")
                                                .font(.system(size: 13, weight: .regular, design: .rounded))
                                        }
                                        Spacer()
                                    }

                                    HStack {
                                        Image(systemName: "play")
                                            .resizable()
                                            .aspectRatio(contentMode: .fit)
                                            .foregroundColor(.white)
                                            .padding(5)
                                            .frame(height: 55)
                                        VStack(alignment: .leading) {
                                            Text("Standalone App")
                                                .font(.system(size: 16, weight: .bold, design: .rounded))
                                            Text("Make sure to run this app as a stand alone app. Running in the preview can result in slowdowns and unexpected behavior.")
                                                .font(.system(size: 13, weight: .regular, design: .rounded))
                                        }
                                        Spacer()
                                    }

                                }
                                .frame(width: 400)
                            } didClick: {
                                HelpController.shared.advanceHelpView(track: .starting)
                            }
                            .helpTag(enabled: HelpController.shared.isEnabled("Click Planet")) {
                                VStack {
                                    Text("Editing The Simulation")
                                        .font(.system(size: 24, weight: .bold, design: .rounded))
                                    Text("To edit different planets in the simulation you can select them by tapping on the planet. If you want to create a new planet, tap anywhere in empty space")
                                        .font(.system(size: 16, weight: .regular, design: .rounded))

                                    HStack {
                                        Text("Edit Planet")
                                            .foregroundColor(Color(uiColor: .label))
                                            .frame(width: 130, height: 32)
                                            .background(Color(uiColor: .systemGroupedBackground))
                                            .cornerRadius(7)
                                        VStack(alignment: .leading) {
                                            Text("Edit Planet Button")
                                                .font(.system(size: 16, weight: .bold, design: .rounded))
                                            Text("This button allows you to edit different attributes of a planet.")
                                                .font(.system(size: 13, weight: .regular, design: .rounded))
                                        }
                                        Spacer()
                                    }
                                    
                                    HStack {
                                        Text("Center Planet")
                                            .foregroundColor(Color(uiColor: .label))
                                            .frame(width: 130, height: 32)
                                            .background(Color(uiColor: .systemGroupedBackground))
                                            .cornerRadius(7)
                                        VStack(alignment: .leading) {
                                            Text("Center Planet Toggle")
                                                .font(.system(size: 16, weight: .bold, design: .rounded))
                                            Text("Clicking this button will center the simulation on the selected planet.")
                                                .font(.system(size: 13, weight: .regular, design: .rounded))
                                        }
                                        Spacer()
                                    }

                                    HStack {
                                        Text("Explore Planet")
                                            .foregroundColor(Color(uiColor: .label))
                                            .frame(width: 130, height: 32)
                                            .background(Color(uiColor: .systemGroupedBackground))
                                            .cornerRadius(7)
                                        VStack(alignment: .leading) {
                                            Text("Explore Planet Button")
                                                .font(.system(size: 16, weight: .bold, design: .rounded))
                                            Text("Clicking this Button will open the ecosystem simulation on the selected planet.")
                                                .font(.system(size: 13, weight: .regular, design: .rounded))
                                        }
                                        Spacer()
                                    }

                                }
                                .frame(width: 400)
                            } didClick: {
                                HelpController.shared.advanceHelpView(track: .starting)
                            }

                        
                        // Control Strip
                        PlanetaryControlStrip(reader: reader)
                            .environmentObject(universe)

                        // Universe Stats
                        if universe.shouldShowStats {
                            PlanetaryStats()
                                .environmentObject(universe)
                        }

                        // Bodies Panel Overlay
                        if universe.shouldShowBodiesPanel {
                            PlanetaryBodies(reader: reader)
                                .environmentObject(universe)
                        }
                        
                        // Settings View
                        if universe.shouldShowSettings {
                            PlanetarySettings(reader: reader)
                                .environmentObject(universe)
                        }
                        
                        // Planet Creator / Editor Tool
                        if universe.isEditingPlanet {
                            PlanetEditor(reader: reader)
                                .environmentObject(universe)
                        }
                    } else {
                        SpriteView(scene: simulationScene)
                            .ignoresSafeArea()

                        // Control Strip
                        EcosystemControlStrip(reader: reader)
                            .environmentObject(universe)

                        // Universe Stats
                        if universe.shouldShowStats {
                            EcosystemStats()
                                .environmentObject(universe)
                        }
                    }
                }
            }
            .statusBar(hidden: true)
            .ignoresSafeArea()
            .onAppear {
                // Set up all of the Sprite Kit scenes with the proper references and settings.
                planetScene.universe = universe
                universe.mainScene = planetScene
                planetScene.size = CGSize(width: 5000, height: 5000)
                planetScene.scaleMode = .resizeFill
                planetScene.focusToPlanet(universe.bodies[4], shouldFocus: false)
                
                simulationScene.universe = universe
                universe.ecosystemScene = simulationScene
                simulationScene.size = CGSize(width: 5000, height: 5000)
                simulationScene.scaleMode = .resizeFill
                
                waitingScene.universe = universe
                universe.waitingScene = waitingScene
                waitingScene.size = CGSize(width: 5000, height: 5000)
                waitingScene.scaleMode = .resizeFill
            }
        }
    }
}
