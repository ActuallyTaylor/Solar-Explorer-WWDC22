//
//  SolarExplorer.swift
//  Solar Explorer
//
//  Created by Zachary lineman
//

import SwiftUI

@main
struct SolarExplorer: App {
    var body: some Scene {
        WindowGroup {
            PlanetarySimulation()
                .preferredColorScheme(.dark)
        }
    }
}
