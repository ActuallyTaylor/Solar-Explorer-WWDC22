//
//  PlanetScene.swift
//  Solar Explorer
//
//  Created by Zachary lineman
//

import SwiftUI
import SpriteKit

// This scene contains all of the code for displaying the planets moving around the universe.
class PlanetScene: SKScene {
    
    var universe: Universe!
    let futureSimulationNode: SKShapeNode = SKShapeNode()
    
    // MARK: Camera
    let cameraNode = SKCameraNode()
    var isMovingCamera: Bool = false
    var lastCameraScale: CGFloat = 0.0
    var offsetX: CGFloat = 0.0
    var offsetY: CGFloat = 0.0
    
    // MARK: Focusing & Touch nodes
    var touchedNode: SKNode?
    var focusingPlanetIndex: Int = 0
    var isFocusingPlanet: Bool = false
    var isCenteredOnPlanet: Bool = false

    var justClickedOnNode: Bool = false
    var justClickedButton: Bool = false

    //MARK: Font
    var defaultFont: String = UIFont.rounded(ofSize: 16, weight: .regular).fontName//"HelveticaNeue"
    var defaultBoldFont: String = UIFont.rounded(ofSize: 16, weight: .bold).fontName
    
    // MARK: Focus
    let focusNode: SKNode = SKNode()
    var focusCircle: SKShapeNode = SKShapeNode()
    var focusLine: SKShapeNode = SKShapeNode()
    var focusSquare: SKShapeNode = SKShapeNode()
    var focusSquareTitle: SKLabelNode!
    var focusSquareVelocity: SKLabelNode!
    var focusSquarePosition: SKLabelNode!
    var focusEditPlanetButton: SKLabelNode!
    var focusEditPlanetButtonBackground: SKShapeNode!
    var focusCenterPlanetButton: SKLabelNode!
    var focusCenterPlanetButtonBackground: SKShapeNode!
    var focusExplorePlanetButton: SKLabelNode!
    var focusExplorePlanetButtonBackground: SKShapeNode!

    override func sceneDidLoad() {
        self.backgroundColor = UIColor.black
        cameraNode.position = CGPoint(x: 0, y: 0)
        cameraNode.name = "Camera"
        addChild(cameraNode)
        camera = cameraNode
        addChild(futureSimulationNode)
        futureSimulationNode.name = "Background"
                
        NotificationCenter.default.addObserver(self, selector: #selector(resetSim), name: .simulationReset, object: nil)
    }
    
    override func didMove(to view: SKView) {
        universe.mainScene = self
        addGestures()
        removeChildren(in: universe.bodies.map({$0.node}))
        removeChildren(in: universe.bodies.map({$0.pathNode}))
        removeChildren(in: [focusNode])

        for body in universe.bodies {
            addChild(body.pathNode)
            addChild(body.node)
        }
        
        addChild(focusNode)
    }
    
    override func update(_ currentTime: TimeInterval) {
        super.update(currentTime)
        if !(universe.bodies.count > focusingPlanetIndex) { return }

        if isFocusingPlanet {
            let position = universe.bodies[focusingPlanetIndex].currentPosition
            let velocity = universe.bodies[focusingPlanetIndex].currentVelocity
            focusNode.position = CGPoint(x: position.x, y: position.y)
            focusSquareVelocity.text = "Velocity X: \(String(format: "%.2f", velocity.dx)), Y: \(String(format: "%.2f", velocity.dy))"
            focusSquarePosition.text = "Position X: \(String(format: "%.2f", position.x)), Y: \(String(format: "%.2f", position.y))"

        }
        if isCenteredOnPlanet {
            let position = universe.bodies[focusingPlanetIndex].currentPosition
            self.cameraNode.position = CGPoint(x: position.x, y: position.y)
        }
    }

    @objc func resetSim() {
        removeChildren(in: [focusNode])

        for body in universe.bodies {
            addChild(body.pathNode)
            addChild(body.node)
        }
        
        addChild(focusNode)
    }

    func setupFocusCircle(index: Int, oldIndex: Int) {
        focusNode.removeChildren(in: [focusCircle, focusLine, focusSquare])
        let planet = universe.bodies[index]
        
        // MARK: Circle & Line
        focusCircle = SKShapeNode(circleOfRadius: planet.radius + 10)
        focusCircle.strokeColor = .white
        focusCircle.lineWidth = 5
        
        focusLine = SKShapeNode()
        let path = CGMutablePath()
        path.move(to: CGPoint(x: 0, y: planet.radius + 22))
        path.addLine(to: CGPoint(x: 0, y: 100))
        
        focusLine.path = path
        focusLine.strokeColor = .white
        focusLine.lineWidth = 3
        
        // MARK: Background
        focusSquare = SKShapeNode(rect: CGRect(x: 0, y: 0, width: 300, height: 200), cornerRadius: 20)
        focusSquare.position = CGPoint(x: -150, y: planet.radius + 78)
        focusSquare.fillColor = .systemFill
        
        // MARK: Title
        focusSquareTitle = SKLabelNode(text: planet.name)
        focusSquareTitle.fontSize = 24
        focusSquareTitle.fontName = defaultBoldFont
        focusSquareTitle.fontColor = .white
        focusSquareTitle.verticalAlignmentMode = .center
        focusSquareTitle.horizontalAlignmentMode = .center

        focusSquareTitle.position = CGPoint(x: 150, y: 175)
        
        // MARK: Position & Velocity
        focusSquarePosition = SKLabelNode(text: "Position X: \(String(format: "%.2f", planet.currentPosition.x)), Y: \(String(format: "%.2f", planet.currentPosition.y))")
        focusSquarePosition.fontSize = 18
        focusSquarePosition.fontName = defaultFont
        focusSquarePosition.fontColor = .white
        focusSquarePosition.verticalAlignmentMode = .center
        focusSquarePosition.horizontalAlignmentMode = .left
        focusSquarePosition.position = CGPoint(x: 10, y: 150)

        focusSquareVelocity = SKLabelNode(text: "Velocity X: \(String(format: "%.2f", planet.currentVelocity.dx)), Y: \(String(format: "%.2f", planet.currentVelocity.dy))")
        focusSquareVelocity.fontSize = 18
        focusSquareVelocity.fontName = defaultFont
        focusSquareVelocity.fontColor = .white
        focusSquareVelocity.verticalAlignmentMode = .center
        focusSquareVelocity.horizontalAlignmentMode = .left
        focusSquareVelocity.position = CGPoint(x: 10, y: 120)

        // MARK: Buttons
        // Edit Button
        focusEditPlanetButton = SKLabelNode(text: "Edit Planet")
        focusEditPlanetButton.fontName = defaultFont
        focusEditPlanetButton.name = "Edit Planet"
        focusEditPlanetButton.verticalAlignmentMode = .center
        focusEditPlanetButton.horizontalAlignmentMode = .center
        focusEditPlanetButton.fontSize = 20
        focusEditPlanetButton.fontColor = .label
        focusEditPlanetButton.position = CGPoint(x: 65, y: 16)

        focusEditPlanetButtonBackground = SKShapeNode(rect: CGRect(x: 0, y: 0, width: 130, height: 32), cornerRadius: 7)
        focusEditPlanetButtonBackground.name = "Edit Planet"
        focusEditPlanetButtonBackground.fillColor = .systemGroupedBackground
        focusEditPlanetButtonBackground.strokeColor = .clear
        focusEditPlanetButtonBackground.position = CGPoint(x: 10, y: 60)
        focusEditPlanetButtonBackground.addChild(focusEditPlanetButton)

        // Center Button
        focusCenterPlanetButton = SKLabelNode(text: "Center Planet")
        focusCenterPlanetButton.fontName = defaultFont
        focusCenterPlanetButton.name = "Center Planet"
        focusCenterPlanetButton.verticalAlignmentMode = .center
        focusCenterPlanetButton.horizontalAlignmentMode = .center
        focusCenterPlanetButton.fontSize = 20
        focusCenterPlanetButton.fontColor = .label
        focusCenterPlanetButton.position = CGPoint(x: 65, y: 16)

        focusCenterPlanetButtonBackground = SKShapeNode(rect: CGRect(x: 0, y: 0, width: 130, height: 32), cornerRadius: 7)
        focusCenterPlanetButtonBackground.name = "Center Planet"
        focusCenterPlanetButtonBackground.fillColor = .systemGroupedBackground
        if index == oldIndex && isCenteredOnPlanet {
            focusCenterPlanetButtonBackground.fillColor = .systemBlue
            focusCenterPlanetButtonBackground.strokeColor = .clear
        }
        focusCenterPlanetButtonBackground.strokeColor = .clear
        focusCenterPlanetButtonBackground.position = CGPoint(x: 160, y: 60)
        focusCenterPlanetButtonBackground.addChild(focusCenterPlanetButton)

        // Explore Button
        focusExplorePlanetButton = SKLabelNode(text: "Explore Planet")
        focusExplorePlanetButton.fontName = defaultFont
        focusExplorePlanetButton.name = "Explore Planet"
        focusExplorePlanetButton.verticalAlignmentMode = .center
        focusExplorePlanetButton.horizontalAlignmentMode = .center
        focusExplorePlanetButton.fontSize = 20
        focusExplorePlanetButton.fontColor = .label
        focusExplorePlanetButton.position = CGPoint(x: 140, y: 16)

        focusExplorePlanetButtonBackground = SKShapeNode(rect: CGRect(x: 0, y: 0, width: 280, height: 32), cornerRadius: 7)
        focusExplorePlanetButtonBackground.name = "Explore Planet"
        focusExplorePlanetButtonBackground.fillColor = .systemGroupedBackground
        focusExplorePlanetButtonBackground.strokeColor = .clear
        focusExplorePlanetButtonBackground.position = CGPoint(x: 10, y: 10)
        focusExplorePlanetButtonBackground.addChild(focusExplorePlanetButton)

        
        // MARK: Add Children to focus square
        focusSquare.addChild(focusExplorePlanetButtonBackground)
        focusSquare.addChild(focusCenterPlanetButtonBackground)
        focusSquare.addChild(focusEditPlanetButtonBackground)
        focusSquare.addChild(focusSquarePosition)
        focusSquare.addChild(focusSquareVelocity)
        focusSquare.addChild(focusSquareTitle)
        
        focusNode.addChild(focusSquare)
        focusNode.addChild(focusLine)
        focusNode.addChild(focusCircle)
    }
       
    func fadeIn(node: SKNode) {
        node.alpha = 0.0
        node.isHidden = false
        node.run(SKAction.fadeIn(withDuration: 0.25))
    }
    
    func fadeOut(node: SKNode) {
        node.run(SKAction.fadeOut(withDuration: 0.25))
        Dispatch.delay(seconds: 0.5) {
            node.alpha = 0.0
            node.isHidden = true
        }
    }
}

// MARK: Camera Movements
extension PlanetScene {
    func focusToPlanet(_ planet: Planet, shouldFocus: Bool = true) {
        let position = planet.currentPosition
        self.cameraNode.position = CGPoint(x: position.x, y: position.y)
        
        if shouldFocus {
            let oldIndex = focusingPlanetIndex
            let planetIndex = universe.bodies.firstIndex(of: planet) ?? 0
            isFocusingPlanet = true
            focusingPlanetIndex = planetIndex
            setupFocusCircle(index: planetIndex, oldIndex: oldIndex)
            fadeIn(node: focusNode)
        }
    }
    
    func addGestures() {
        let panGestureRecognizer = UIPanGestureRecognizer(target: self, action: #selector(self.handlePan(recognizer:)))
        panGestureRecognizer.maximumNumberOfTouches = 2
        self.view!.addGestureRecognizer(panGestureRecognizer)
        
        let pinchGestureRecongizer = UIPinchGestureRecognizer(target: self, action: #selector(handlePinch(recognizer:)))
        pinchGestureRecongizer.scale = 1.0
        self.view!.addGestureRecognizer(pinchGestureRecongizer)
    }

    @objc func handlePinch(recognizer: UIPinchGestureRecognizer) {
        if(recognizer.state != .changed) {
            if recognizer.state == .began {
                isMovingCamera = true
                lastCameraScale = cameraNode.xScale
            } else {
                isMovingCamera = false
            }
            return
        }

        let zoomInAction = SKAction.scale(to: lastCameraScale * 1 / recognizer.scale, duration: 0.1)
        cameraNode.run(zoomInAction)
    }
    
    @objc func handlePan(recognizer: UIPanGestureRecognizer) {
        if recognizer.state != .changed {
            if recognizer.state == .began {
                isMovingCamera = true
            } else {
                isMovingCamera = false
            }
            return
        }
        let translation = recognizer.translation(in: recognizer.view!)
        offsetX += translation.x
        offsetY -= translation.y
        
        self.cameraNode.position.x -= translation.x
        self.cameraNode.position.y += translation.y
        
        recognizer.setTranslation(CGPoint.zero, in: recognizer.view)
    }
}

// MARK: Touch Interactions
extension PlanetScene {
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        if !isMovingCamera && !justClickedOnNode {
            guard let touch = touches.first else { return }

            let location = touch.location(in: self)
            
            let node = atPoint(location)

            if node.name?.contains("Path") ?? false { return }
            if node.name == "Edit Planet" {
                guard let touchedNode = touchedNode else {
                    Log(level: .Error, "Unable to get touched node")
                    return
                }
                let planetIndex = universe.bodies.firstIndex { Planet in
                    return Planet.id.uuidString == touchedNode.name
                }
                justClickedButton = true
                universe.editPlanet(index: planetIndex ?? 0)
                fadeOut(node: focusNode)
            } else if node.name == "Center Planet" {
                justClickedButton = true
                isCenteredOnPlanet.toggle()
                focusCenterPlanetButtonBackground.fillColor = isCenteredOnPlanet ? .systemBlue : .systemGroupedBackground
            } else if node.name == "Explore Planet" {
                guard let touchedNode = touchedNode else { return }
                if let planet = universe.bodies.first(where: { Planet in
                    return Planet.id.uuidString == touchedNode.name
                }) {
                    justClickedButton = true
                    universe.explore(planet: planet)
                    fadeOut(node: focusNode)
                }
            } else {
                if !(node.name == "Background") && node.name != nil {
                    touchedNode = node
                    let planetIndex = universe.bodies.firstIndex { Planet in
                        return Planet.id.uuidString == node.name
                    }
                    if planetIndex != nil {
                        let oldIndex = focusingPlanetIndex
                        if planetIndex != focusingPlanetIndex {
                            isCenteredOnPlanet = false
                        }
                        justClickedOnNode = true
                        isFocusingPlanet = true
                        focusingPlanetIndex = planetIndex ?? 0
                        setupFocusCircle(index: planetIndex ?? 0, oldIndex: oldIndex)
                        fadeIn(node: focusNode)
                    }
                }
            }
        }
    }
    
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        if universe.isEditingPlanet { return }
        if !isMovingCamera && !justClickedOnNode && !justClickedButton {
            if isFocusingPlanet {
                isFocusingPlanet = false
                fadeOut(node: focusNode)
                
                return
            }
            guard let touch = touches.first else { return }
            let location = touch.location(in: self)
            
            universe.addPlanet(location: location)
            
            if universe.bodies.last != nil {
                addChild(universe.bodies.last!.pathNode)
                addChild(universe.bodies.last!.node)
            }
        } else if justClickedOnNode || justClickedButton {
            justClickedOnNode = false
            justClickedButton = false
        }
    }
}
