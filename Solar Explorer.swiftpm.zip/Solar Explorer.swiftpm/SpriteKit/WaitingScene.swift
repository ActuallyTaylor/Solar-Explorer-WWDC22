//
//  WaitingScene.swift
//  Solar Explorer
//
//  Created by Zachary lineman.
//

import SpriteKit

// This scene contains the little playable game for when you are waiting for long tasks.
class WaitingScene: SKScene {

    // MARK: Things from the universe view
    var universe: Universe!
    var waitingForPlanet: Planet!
    
    var stepToSyncTo: Int = 0
    
    //MARK: Font
    var defaultFont: String = UIFont.rounded(ofSize: 16, weight: .regular).fontName
    var defaultBoldFont: String = UIFont.rounded(ofSize: 16, weight: .bold).fontName

    // MARK: Nodes
    // Loading Node
    var loadingNode: SKLabelNode = SKLabelNode(text: "Syncing Planet...")
    var loadingDescription: SKLabelNode = SKLabelNode(text: "Currently synchronize the ecosystem simulation with the rest of the universe. While you wait, please enjoy a game of Emoji Run!")

    var totalWaitTime: Int = 0
    
    // MARK: Running Game
    var score: Int = 0
    var distanceToNextObstacle: Int = 0
    var distanceCounter: Int = 0
    
    var gravitationalConstant: CGFloat = -0.2
    var playerVelocity: CGVector = CGVector(dx: 0, dy: 0)
    var playerMass: CGFloat = 2
    var isJumping: Bool = false

    var movementSpeed: CGFloat = 5
    var obstacles: [SKLabelNode] = []
    var runningSprite: SKLabelNode = SKLabelNode(text: "🦖")
    var groundNode: SKShapeNode = SKShapeNode()
    var groundHeight: CGFloat = 0
    
    var didLoose: Bool = false
    var lostLabel: SKLabelNode = SKLabelNode(text: "You Lost! Your Score Was: ")
    var lostSubtitle: SKLabelNode = SKLabelNode(text: "Tap to restart")
    var oneTouchGrace: Bool = false
    let oneTouchGraceTime: Int = 30
    var oneTouchGraceCounter: Int = 0
    
    override func sceneDidLoad() {
        self.backgroundColor = UIColor.black

        loadingNode.fontName = defaultBoldFont
        loadingNode.name = "Syncing Planet..."
        loadingNode.verticalAlignmentMode = .center
        loadingNode.horizontalAlignmentMode = .center
        loadingNode.fontSize = 32
        loadingNode.fontColor = .white

        loadingDescription.fontName = defaultFont
        loadingDescription.name = "Description"
//        loadingDescription.horizontalAlignmentMode = .center
        loadingDescription.fontSize = 22
        loadingDescription.fontColor = .white.withAlphaComponent(0.8)
        loadingDescription.preferredMaxLayoutWidth = (view?.bounds.size.width ?? UIScreen.main.bounds.width) - 80
        loadingDescription.lineBreakMode = .byWordWrapping
        loadingDescription.numberOfLines = 0

        addChild(loadingNode)
        addChild(loadingDescription)
        
        setupGame()
    }
    
    func generateCactus() -> SKLabelNode {
        let height = (view?.bounds.size.height ?? UIScreen.main.bounds.height) - 300
        let width = (view?.bounds.size.width ?? UIScreen.main.bounds.width)
        let cactusSprite: SKLabelNode = SKLabelNode(text: "🌵")
        cactusSprite.position = CGPoint(x: width, y: height / 2 + 5)
        cactusSprite.fontSize = 40
        cactusSprite.name = UUID().uuidString

        return cactusSprite
    }
    
    func setupGame() {
        let height = (view?.bounds.size.height ?? UIScreen.main.bounds.height) - 300
        let width = (view?.bounds.size.width ?? UIScreen.main.bounds.width)
    
        lostLabel.horizontalAlignmentMode = .center
        lostLabel.position = CGPoint(x: width / 2, y: height / 2 + 200)
        lostLabel.fontSize = 32
        lostLabel.fontColor = .white
        lostLabel.fontName = defaultBoldFont
        lostLabel.alpha = 0
        lostLabel.preferredMaxLayoutWidth = (view?.bounds.size.width ?? UIScreen.main.bounds.width) - 30

        lostSubtitle.horizontalAlignmentMode = .center
        lostSubtitle.position = CGPoint(x: width / 2, y: height / 2 + 160)
        lostSubtitle.fontSize = 22
        lostSubtitle.fontColor = .white.withAlphaComponent(0.8)
        lostSubtitle.fontName = defaultFont
        lostSubtitle.alpha = 0
        
        groundHeight = height / 2
        
        runningSprite.fontSize = 48
        runningSprite.xScale = -1
        runningSprite.position = CGPoint(x: 100, y: height / 2 + 5)
        
        var splinePoints = [CGPoint(x: 0, y: (height / 2)), CGPoint(x: width, y: (height / 2))]
        groundNode = SKShapeNode(splinePoints: &splinePoints, count: 2)
        
        generateObstacles()
        addChild(runningSprite)
        addChild(groundNode)
        addChild(lostLabel)
        addChild(lostSubtitle)
    }
    
    func addObstacles() {
        for item in obstacles {
            if item.parent == nil {
                addChild(item)
            }
        }
    }
    
    func loose() {
        didLoose = true
        oneTouchGrace = true
        lostLabel.text = "You Lost! Your Score Was: \(score)"
        fadeIn(node: lostLabel)
        fadeIn(node: lostSubtitle)
    }
    
    func restart() {
        fadeOut(node: lostLabel)
        fadeOut(node: lostSubtitle)
        distanceCounter = 0
        distanceToNextObstacle = 0
        score = 0
        for item in obstacles {
            item.removeFromParent()
        }
        obstacles.removeAll()
        generateObstacles()
        addObstacles()
        didLoose = false
        oneTouchGrace = false
    }
    
    func generateObstacles() {
        if distanceToNextObstacle <= distanceCounter {
            obstacles.append(generateCactus())
            addObstacles()
            distanceCounter = 0
            distanceToNextObstacle = Random.int(range: 40..<100)
        } else {
            distanceCounter += 1
        }
    }
    
    override func didMove(to view: SKView) {
        loadingNode.position = CGPoint(x: view.frame.width / 2, y: view.frame.height - 90)
        loadingDescription.position = CGPoint(x: view.frame.width / 2 , y: view.frame.height - 120 - loadingDescription.frame.height)
    }
    
    override func update(_ currentTime: TimeInterval) {
        super.update(currentTime)
        if !waitingForPlanet.needsToSyncEcosystem {
            universe.waitingForSync = false
            universe.explore(planet: waitingForPlanet, needToSync: false)
            return
        }
        
        Dispatch.main { [self] in
            loadingNode.text = "Syncing Planet... (\(String(format: "%.2f", (Double(waitingForPlanet.currentEcosystemStep) / Double(stepToSyncTo / universe.ecosystemStepToPhysicsStepRatio)).clamped(to: 0...100) * 100))%)"
        }
        
        // MARK: Detect Collision
        if !didLoose {
            generateObstacles()
            for node in obstacles {
                if node.position.x > 0 {
                    if (runningSprite.position.x <= node.position.x + node.frame.width - 5 && runningSprite.position.x + runningSprite.frame.width - 5 >= node.position.x) &&
                        (runningSprite.position.y <= node.position.y + node.frame.height - 5 && runningSprite.position.y + runningSprite.frame.height - 5 >= node.position.y) {
                        loose()
                        break
                    }
                } else {
                    if node.parent != nil {
                        node.removeFromParent()
                        obstacles.removeAll { n in return n == node }
                        score += 1
                    }
                }
            }
            
            
            // MARK: Custom Physics
            playerVelocity.dy += playerMass * gravitationalConstant
            runningSprite.position.y += playerVelocity.dy

            if runningSprite.position.y <= groundHeight {
                playerVelocity.dy = 0
                runningSprite.position.y = groundHeight
                isJumping = false
            }

            totalWaitTime += 1
            for item in obstacles {
                item.position.x = item.position.x - movementSpeed
            }
        } else {
            if oneTouchGrace {
                if oneTouchGraceCounter > oneTouchGraceTime {
                    oneTouchGrace = false
                    oneTouchGraceCounter = 0
                } else {
                    oneTouchGraceCounter += 1
                }
            }
        }
    }
    
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        if didLoose {
            if oneTouchGrace {
                oneTouchGrace = false
            } else {
                restart()
            }
        } else {
            if !isJumping {
                isJumping = true
                playerVelocity.dy += 10
            }
        }
    }
    
    func fadeIn(node: SKNode) {
        node.alpha = 0.0
        node.isHidden = false
        node.run(SKAction.fadeIn(withDuration: 0.25))
    }
    
    func fadeOut(node: SKNode) {
        node.run(SKAction.fadeOut(withDuration: 0.25))
        Dispatch.delay(seconds: 0.5) {
            node.alpha = 0.0
            node.isHidden = true
        }
    }

}
