//
//  EcosystemScene.swift
//  Solar Explorer
//
//  Created by Zachary lineman
//

import SpriteKit

// This scene is what shows the ecosystem simulation.
class EcosystemScene: SKScene {
    var universe: Universe!
    
    // MARK: Camera
    let cameraNode = SKCameraNode()
    var isMovingCamera: Bool = false
    var lastCameraScale: CGFloat  = 0.0
    var offsetX: CGFloat = 0.0
    var offsetY: CGFloat = 0.0
    
    // MARK: UI Interactions
    var justClickedOnNode: Bool = false
    var justClickedButton: Bool = false
    
    //MARK: Font
    var defaultFont: String = UIFont.rounded(ofSize: 16, weight: .regular).fontName//"HelveticaNeue"
    var defaultBoldFont: String = UIFont.rounded(ofSize: 16, weight: .bold).fontName

    // MARK: Focus
    var touchedNode: SKNode?
    var focusingCreatureUUID: String = ""
    var isFocusingCreature: Bool = false

    let focusNode: SKNode = SKNode()
    var focusCircle: SKShapeNode = SKShapeNode()
    var focusLine: SKShapeNode = SKShapeNode()
    var focusSquare: SKShapeNode = SKShapeNode()
    var focusSquareTitle: SKLabelNode!
    var focusCurrentlyFulfilling: SKLabelNode!
    
    var focusHungerBarBackground: SKShapeNode!
    var focusHungerBarForeground: SKSpriteNode!
    var focusHungerBarText: SKLabelNode!

    var focusThirstBarBackground: SKShapeNode!
    var focusThirstBarForeground: SKSpriteNode!
    var focusThirstBarText: SKLabelNode!

    var focusReproductionBarBackground: SKShapeNode!
    var focusReproductionBarForeground: SKSpriteNode!
    var focusReproductionBarText: SKLabelNode!
    
    var focusGestationBarBackground: SKShapeNode!
    var focusGestationBarForeground: SKSpriteNode!
    var focusGestationBarText: SKLabelNode!

    override func sceneDidLoad() {
        self.backgroundColor = UIColor.black
        cameraNode.position = CGPoint(x: 0, y: 0)
        cameraNode.name = "Camera"
        addChild(cameraNode)
        camera = cameraNode
        
        addChild(focusNode)
        
        NotificationCenter.default.addObserver(self, selector: #selector(updatePlanet), name: .planetAddedCreature, object: nil)
    }
    
    override func didMove(to view: SKView) {
        addGestures()
        isFocusingCreature = false
        universe.ecosystemScene = self
    }

    
    override func update(_ currentTime: TimeInterval) {
        super.update(currentTime)
        guard let planet = universe.currentlyExploringPlanet else { return }
        let creatures = planet.creatures

        if isFocusingCreature {
            if let creature = creatures.first(where: { creature in
                return creature.id.uuidString == focusingCreatureUUID
            }) {
                let position = creature.currentPosition
                focusNode.position = CGPoint(x: position.x, y: position.y)
                focusCurrentlyFulfilling.text = "Searching for \(creature.currentlyFulfilling)"
                
                let hungerAction = SKAction.resize(toWidth: (creature.hunger/100) * 280, duration: 0)
                focusHungerBarForeground.run(hungerAction)
                focusHungerBarText.text = "Hunger: \(String(format: "%.2f", creature.hunger))%"
                
                let thirstAction = SKAction.resize(toWidth: (creature.thirst/100) * 280, duration: 0)
                focusThirstBarForeground.run(thirstAction)
                focusThirstBarText.text = "Thirst: \(String(format: "%.2f", creature.thirst))%"
                
                let reproductionAction = SKAction.resize(toWidth: (creature.needToReproduce/100) * 280, duration: 0)
                focusReproductionBarForeground.run(reproductionAction)
                focusReproductionBarText.text = "Reproduction Need: \(String(format: "%.2f", creature.needToReproduce))%"
                
                let gestationAction = SKAction.resize(toWidth: (creature.gestationCounter / creature.gestationPeriod) * 280, duration: 0)
                focusGestationBarForeground.run(gestationAction)
                focusGestationBarText.text = "Gestation: \(String(format: "%.2f", (creature.gestationCounter / creature.gestationPeriod) * 100))%"

            } else {
                isFocusingCreature = false
            }
        }
    }
    
    @objc func updatePlanet() {
        guard let currentlyExploringPlanet = universe.currentlyExploringPlanet else { return }
        removeChildren(in: currentlyExploringPlanet.creatures.map({$0.node}))
        removeChildren(in: [focusNode])
        
        for creature in currentlyExploringPlanet.creatures {
            creature.node.removeFromParent()
            addChild(creature.node)
        }
        
        addChild(focusNode)
    }
    
    func updateSceneForPlanet(planet: Planet) {
        if universe.currentlyExploringPlanet != nil {
            removeChildren(in: universe.currentlyExploringPlanet!.creatures.map({$0.node}))
            removeChildren(in: universe.currentlyExploringPlanet!.world.map({$0.node}))
        }
        removeChildren(in: planet.creatures.map({$0.node}))
        removeChildren(in: planet.world.map({$0.node}))
        removeChildren(in: [focusNode])

        for worldItem in planet.world {
            addChild(worldItem.node)
        }
        
        for creature in planet.creatures {
            addChild(creature.node)
        }
        
        addChild(focusNode)
    }
    
    
    func setupFocusCircle(creature: Creature) {
        focusNode.removeChildren(in: [focusCircle, focusLine, focusSquare])

        // MARK: Circle & Line
        focusCircle = SKShapeNode(circleOfRadius: creature.radius + 10)
        focusCircle.strokeColor = .white
        focusCircle.lineWidth = 5
        
        focusLine = SKShapeNode()
        let path = CGMutablePath()
        path.move(to: CGPoint(x: 0, y: creature.radius + 22))
        path.addLine(to: CGPoint(x: 0, y: 100))
        
        focusLine.path = path
        focusLine.strokeColor = .white
        focusLine.lineWidth = 3
        
        // MARK: Background
        focusSquare = SKShapeNode(rect: CGRect(x: 0, y: 0, width: 300, height: 250), cornerRadius: 20)
        focusSquare.position = CGPoint(x: -150, y: 110)
        focusSquare.fillColor = .systemFill
        
        // MARK: Title
        focusSquareTitle = SKLabelNode(text: creature.species.speciesRepresentation)
        focusSquareTitle.fontSize = 24
        focusSquareTitle.fontName = defaultBoldFont
        focusSquareTitle.fontColor = .white
        focusSquareTitle.verticalAlignmentMode = .center
        focusSquareTitle.horizontalAlignmentMode = .center
        
        focusSquareTitle.position = CGPoint(x: 150, y: 225)
        
        // MARK: Position & Velocity
        focusCurrentlyFulfilling = SKLabelNode(text: "Searching for \(creature.currentlyFulfilling)")
        focusCurrentlyFulfilling.fontSize = 18
        focusCurrentlyFulfilling.fontName = defaultFont
        focusCurrentlyFulfilling.fontColor = .white
        focusCurrentlyFulfilling.verticalAlignmentMode = .center
        focusCurrentlyFulfilling.horizontalAlignmentMode = .center
        focusCurrentlyFulfilling.position = CGPoint(x: 150, y: 200)
        
        // MARK: Needs Bars
        // Hunger Bar
        let hunger = creature.hunger

        focusHungerBarBackground = SKShapeNode(rect: CGRect(x: 0, y: 0, width: 280, height: 30))
        focusHungerBarBackground.fillColor = .gray.withAlphaComponent(0.8)
        focusHungerBarBackground.strokeColor = .clear
        focusHungerBarBackground.position = CGPoint(x: 10, y: 150)

        focusHungerBarForeground = SKSpriteNode(color: .systemRed, size: CGSize(width: (hunger/100)*280, height: 30))
        focusHungerBarForeground.position = CGPoint(x: 10, y: 150)
        focusHungerBarForeground.anchorPoint = CGPoint(x: 0, y: 0)

        focusHungerBarText = SKLabelNode(text: "Hunger: \(String(format: "%.2f", hunger))%")
        focusHungerBarText.fontSize = 18
        focusHungerBarText.fontName = defaultFont
        focusHungerBarText.fontColor = .white
        focusHungerBarText.verticalAlignmentMode = .center
        focusHungerBarText.horizontalAlignmentMode = .center
        focusHungerBarText.position = CGPoint(x: 140, y: 15)

        // Thirst Bar
        let thirst = creature.thirst

        focusThirstBarBackground = SKShapeNode(rect: CGRect(x: 0, y: 0, width: 280, height: 30))
        focusThirstBarBackground.fillColor = .gray.withAlphaComponent(0.8)
        focusThirstBarBackground.strokeColor = .clear
        focusThirstBarBackground.position = CGPoint(x: 10, y: 110)

        focusThirstBarForeground = SKSpriteNode(color: .systemCyan, size: CGSize(width: (thirst/100)*280, height: 30))
        focusThirstBarForeground.position = CGPoint(x: 10, y: 110)
        focusThirstBarForeground.anchorPoint = CGPoint(x: 0, y: 0)

        focusThirstBarText = SKLabelNode(text: "Thirst: \(String(format: "%.2f", thirst))%")
        focusThirstBarText.fontSize = 18
        focusThirstBarText.fontName = defaultFont
        focusThirstBarText.fontColor = .white
        focusThirstBarText.verticalAlignmentMode = .center
        focusThirstBarText.horizontalAlignmentMode = .center
        focusThirstBarText.position = CGPoint(x: 140, y: 15)

        // Reproduction Bar
        let reproductionNeed = creature.needToReproduce
        focusReproductionBarBackground = SKShapeNode(rect: CGRect(x: 0, y: 0, width: 280, height: 30))
        focusReproductionBarBackground.fillColor = .gray.withAlphaComponent(0.8)
        focusReproductionBarBackground.strokeColor = .clear
        focusReproductionBarBackground.position = CGPoint(x: 10, y: 70)

        focusReproductionBarForeground = SKSpriteNode(color: .systemMint, size: CGSize(width: (reproductionNeed/100)*280, height: 30))
        focusReproductionBarForeground.position = CGPoint(x: 10, y: 70)
        focusReproductionBarForeground.anchorPoint = CGPoint(x: 0, y: 0)

        focusReproductionBarText = SKLabelNode(text: "Reproduction Need: \(String(format: "%.2f", reproductionNeed))%")
        focusReproductionBarText.fontSize = 18
        focusReproductionBarText.fontName = defaultFont
        focusReproductionBarText.fontColor = .white
        focusReproductionBarText.verticalAlignmentMode = .center
        focusReproductionBarText.horizontalAlignmentMode = .center
        focusReproductionBarText.position = CGPoint(x: 140, y: 15)

        // Gestation Bar
        let gestation = creature.gestationCounter / creature.gestationPeriod
        focusGestationBarBackground = SKShapeNode(rect: CGRect(x: 0, y: 0, width: 280, height: 30))
        focusGestationBarBackground.fillColor = .gray.withAlphaComponent(0.8)
        focusGestationBarBackground.strokeColor = .clear
        focusGestationBarBackground.position = CGPoint(x: 10, y: 30)

        focusGestationBarForeground = SKSpriteNode(color: .systemPurple, size: CGSize(width: gestation*280, height: 30))
        focusGestationBarForeground.position = CGPoint(x: 10, y: 30)
        focusGestationBarForeground.anchorPoint = CGPoint(x: 0, y: 0)

        focusGestationBarText = SKLabelNode(text: "Gestation: \(String(format: "%.2f", gestation))%")
        focusGestationBarText.fontSize = 18
        focusGestationBarText.fontName = defaultFont
        focusGestationBarText.fontColor = .white
        focusGestationBarText.verticalAlignmentMode = .center
        focusGestationBarText.horizontalAlignmentMode = .center
        focusGestationBarText.position = CGPoint(x: 140, y: 15)
        
        // MARK: Add Children to focus square
        focusSquare.addChild(focusGestationBarBackground)
        focusSquare.addChild(focusGestationBarForeground)
        focusGestationBarForeground.addChild(focusGestationBarText)
        
        focusSquare.addChild(focusReproductionBarBackground)
        focusSquare.addChild(focusReproductionBarForeground)
        focusReproductionBarForeground.addChild(focusReproductionBarText)

        focusSquare.addChild(focusThirstBarBackground)
        focusSquare.addChild(focusThirstBarForeground)
        focusThirstBarForeground.addChild(focusThirstBarText)

        focusSquare.addChild(focusHungerBarBackground)
        focusSquare.addChild(focusHungerBarForeground)
        focusHungerBarForeground.addChild(focusHungerBarText)

        focusSquare.addChild(focusCurrentlyFulfilling)
        focusSquare.addChild(focusSquareTitle)
        
        focusNode.addChild(focusSquare)
        focusNode.addChild(focusLine)
        focusNode.addChild(focusCircle)
    }
    
}

// MARK: Camera Movements
extension EcosystemScene {
    
    func addGestures() {
        let panGestureRecognizer = UIPanGestureRecognizer(target: self, action: #selector(self.handlePan(recognizer:)))
        panGestureRecognizer.maximumNumberOfTouches = 2
        self.view!.addGestureRecognizer(panGestureRecognizer)
        
        let pinchGestureRecongizer = UIPinchGestureRecognizer(target: self, action: #selector(handlePinch(recognizer:)))
        pinchGestureRecongizer.scale = 1.0
        self.view!.addGestureRecognizer(pinchGestureRecongizer)
    }
    
    @objc func handlePinch(recognizer: UIPinchGestureRecognizer) {
        if(recognizer.state != .changed) {
            if recognizer.state == .began {
                isMovingCamera = true
                lastCameraScale = cameraNode.xScale
            } else {
                isMovingCamera = false
            }
            return
        }
        
        let zoomInAction = SKAction.scale(to: lastCameraScale * 1 / recognizer.scale, duration: 0.1)
        cameraNode.run(zoomInAction)
    }
    
    @objc func handlePan(recognizer: UIPanGestureRecognizer) {
        if recognizer.state != .changed {
            if recognizer.state == .began {
                isMovingCamera = true
            } else {
                isMovingCamera = false
            }
            return
        }
        let translation = recognizer.translation(in: recognizer.view!)
        offsetX += translation.x
        offsetY -= translation.y
        
        self.cameraNode.position.x -= translation.x
        self.cameraNode.position.y += translation.y
        
        recognizer.setTranslation(CGPoint.zero, in: recognizer.view)
    }
    
}

// MARK: Touch Interactions
extension EcosystemScene {
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        if !isMovingCamera && !justClickedOnNode {
            guard let touch = touches.first else { return }
            
            let location = touch.location(in: self)
            
            let node = atPoint(location)
            
            if !(node.name == "Background") && node.name != nil {
                touchedNode = node
                if let creature = universe.currentlyExploringPlanet.creatures.first(where: { creature in
                    return creature.id.uuidString == node.name
                }) {
                    justClickedOnNode = true
                    isFocusingCreature = true
                    focusingCreatureUUID = creature.id.uuidString
                    setupFocusCircle(creature: creature)
                    fadeIn(node: focusNode)
                }
            }
        }
    }
    
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        if universe.isEditingPlanet { return }
        if !isMovingCamera && !justClickedOnNode && !justClickedButton {
            if isFocusingCreature {
                isFocusingCreature = false
                fadeOut(node: focusNode)
                
                return
            }
//            guard let touch = touches.first else { return }
//            let location = touch.location(in: self)
            
//            addChild(universe.bodies.last!.pathNode)
//            addChild(universe.bodies.last!.node)
        } else if justClickedOnNode || justClickedButton {
            justClickedOnNode = false
            justClickedButton = false
        }
    }
    
    func fadeIn(node: SKNode) {
        node.alpha = 0.0
        node.isHidden = false
        node.run(SKAction.fadeIn(withDuration: 0.25))
    }
    
    func fadeOut(node: SKNode) {
        node.run(SKAction.fadeOut(withDuration: 0.25))
        Dispatch.delay(seconds: 0.5) {
            node.alpha = 0.0
            node.isHidden = true
        }
    }
    
}
