//
//  Logger.swift
//  Solar Explorer
//
//  Created by Zachary Lineman.
//

import Foundation
import os

//MARK: Logger Config
public struct LoggerConfig {
    public static var defaultLoggingLevel: LogLevel = .Info
    public static var loggingComplexity: LogComplexity = .Simple
}

//MARK: Actual Logging Class
public class Logger: Codable {
    // MARK: - Singleton
    static let shared = Logger()
    
    private static let dateFormatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.calendar = Calendar(identifier: .iso8601)
        formatter.locale = Locale(identifier: "en_US")
        formatter.timeZone = TimeZone(secondsFromGMT: 0)
        formatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss.SSSXXXXX"
        return formatter
    }()

    func log(_ level: LogLevel = LoggerConfig.defaultLoggingLevel, _ items: [String], complexity: LogComplexity = LoggerConfig.loggingComplexity, file: String = #file, line: UInt = #line, function: String = #function) {
        if level != .Fatal {
            //It is not a fatal fail
            switch complexity {
            case .Simple:
                let emoji: String = level.emoji()
                let joinedArray: String = items.joined(separator:" 🚦 ")
                let staticString: String = "\(emoji) \(joinedArray)"
                if #available(macOS 10.12, *) {
//                    debugPrint(staticString)
                    os_log("%{public}s", staticString)
                } else {
                    debugPrint(staticString)
                }
//                os_log(staticString)
            case .Complex:
                let emoji: String = level.emoji()
                let joinedArray: String = items.joined(separator:" 🚦 ")
                let staticString: String = "\(emoji) \(joinedArray) 🚥 ,\(file) @ line \(line), in function \(function)"
                if #available(macOS 10.12, *) {
//                    debugPrint(staticString)
                    os_log("%{public}s", staticString)
                } else {
                    debugPrint(staticString)
                }

//                os_log(staticString)
            }
        } else {
            //It is a fatal fail
            let emoji: String = level.emoji()
            let joinedArray: String = items.joined(separator:" 🚦 ")
            let staticString: String = "\(emoji) \(joinedArray) 🚥 \(file) \(line) \(function)"
            if #available(macOS 10.12, *) {
                debugPrint(staticString)
//                os_log("%{public}s", staticString)
            } else {
                debugPrint(staticString)
            }
            Swift.fatalError(staticString)
        }
    }
}

//MARK: Supporting Structures
public enum LogLevel: NSInteger, Codable {
    case Fatal = 0
    case Error = 1
    case Warn = 2
    case Info = 3
    case Success = 4
    case Working = 5
    case Debug = 6
    
    public func emoji() -> String {
        switch self {
        case .Fatal: return "⚫️ 🛑"
        case .Error: return "⚫️ 🥲"
        case .Warn:  return "⚫️ ⚠️"
        case .Info:  return "⚫️ 🤖"
        case .Success: return "⚫️ ✅"
        case .Working:  return "⚫️ ⚙️"
        case .Debug: return "⚫️ 🔵"
        }
    }
}

public enum LogComplexity: NSInteger, Codable {
    case Simple = 0
    case Complex = 1
}


//MARK: Log Function
func Log(level: LogLevel = LoggerConfig.defaultLoggingLevel,_ items: String..., complexity: LogComplexity = LoggerConfig.loggingComplexity, file: String = #file, line: UInt = #line, function: String = #function) {
    Logger.shared.log(level, items, complexity: complexity, file: file, line: line, function: function)
}
