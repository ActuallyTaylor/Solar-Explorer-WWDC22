//
//  Creature.swift
//  Solar Explorer
//
//  Created by Zachary lineman.
//

import SpriteKit

enum CreatureMetadata {
    case reproductiveAge
    case desirability
    case strength
    case defense
    case sensoryDistance
    case speed
}

final class Creature {
    enum CreatureNeed {
        case food
        case water
        case reproduce
        case any
        case none
        case escape
    }
    
    enum Direction {
        case positiveX
        case negativeX
        case positiveY
        case negativeY
    }
    
    struct State {
        var thirst: Double
        var hunger: Double
        var needToReproduce: Double
        var location: CGPoint
    }
    
    // MARK: General Metadata
    var id: UUID = UUID()
    var species: Species
    var name: String = "Unnamed Creature"
    
    // MARK: Position
    var currentPosition = CGPoint.zero
    
    var position = CGPoint.zero
    var nextPosition = CGPoint.zero
    var radius: CGFloat = 20
    
    var pastStates: [State] = []

    // MARK: Active Metadata
    var needToReproduce: Double = 100 {
        didSet {
            needToReproduce = needToReproduce.clamped(to: 0...100)
        }
    }
    
    var thirst: Double = 100 {
        didSet {
            thirst = thirst.clamped(to: 0...100)
        }
    }
    var beenAtThirstForSteps: Int = 0

    var hunger: Double = 100 {
        didSet {
            hunger = hunger.clamped(to: 0...100)
        }
    }
    var beenAtHungerForSteps: Int = 0
    
    var reproductiveAge: Double = 10
    var desirability: Double = 0
    var strength: Double = 0
    var defense: Double = 0
    var sensoryDistance: Double = 100
    var speed: Double = 1
    
    var mate: Creature?
    var isInGestation: Bool = false
    var gestationCounter: Double = 0
    var gestationPeriod: Double = 1000

    var consumeDistance: Double = 20
    
    //Randomly Moving
    var movingDirection: Direction = .positiveX
    var moveDirectionTime: Int = 0
    var moveDirectionCounter: Int = 0
    
    // Needs
    var currentlyFulfilling: CreatureNeed = .none
    var needTimeout: Int = 0
    var needTimeoutCounter: Int = 0
    
    // Getting Eaten
    var isEaten: Bool = false
    
    // MARK: Genes
    var genes: [Gene] = []
    
    // MARK: Sprite Kit
    var node: SKShapeNode!
    var sensingNode: SKShapeNode!
    var representationLabel: SKLabelNode!

    init(id: UUID = UUID(), species: Species, name: String = "Unnamed Creature", position: CGPoint = CGPoint.zero) {
        self.id = id
        self.species = species
        self.name = name
        self.position = position
        self.genes = species.startingGenes
        
        // Give random active metadata
        self.needToReproduce = Random.double(range: 0...100)
        self.thirst = Random.double(range: 0...100)
        self.hunger = Random.double(range: 0...100)
        
        setupNodes()
    }
    
    // Create a new creature based on parent creatures.
    init(birthParent: Creature, givingParent: Creature) {
        self.species = birthParent.species
        self.position = CGPoint(x: birthParent.nextPosition.x - 50, y: birthParent.position.y - 50)
        
        // MARK: Randomize & Combine genes
        let minGeneCount = min(birthParent.genes.count, givingParent.genes.count)
        
        var pairedGenes: [(Gene, Gene?)] = []
        
        for n in 0..<minGeneCount {
            let birthGene = birthParent.genes[n]
            pairedGenes.append((birthGene, nil))
        }
        
        for n in 0..<minGeneCount {
            let givingGene = givingParent.genes[n]
            for i in 0..<pairedGenes.count {
                if pairedGenes[i].0.effectSpot == givingGene.effectSpot && pairedGenes[i].1 == nil {
                    pairedGenes[i] = (pairedGenes[i].0, givingGene)
                    break
                }
            }
        }
        
        for pair in pairedGenes {
            let birthGene = pair.0
            if let givingGene = pair.1 {
                var value: Double = 0
                
                let selectGeneFromRandomParentValue = Random.int(range: 0...2)
                if selectGeneFromRandomParentValue ==  0 {
                    //From Life Form 1
                    value = birthGene.strength
                } else if selectGeneFromRandomParentValue == 1 {
                    //From Life Form 2
                    value = givingGene.strength
                } else if selectGeneFromRandomParentValue == 2 {
                    //Average of the two
                    value = (birthGene.strength + givingGene.strength) / 2
                }
                if Random.checkPercentage_Double(percentage: 0.05) {
                    value += Random.double(range: -25...25)
                }
                
                let gene = Gene(geneName: "", effectSpot: .strength, strength: value)
                genes.append(gene)

            }
        }

        // Give random active metadata
        self.needToReproduce = Random.double(range: 0...100)
        self.thirst = Random.double(range: 0...100)
        self.hunger = Random.double(range: 0...100)
        
        setupNodes()
    }

    func setupNodes() {
        node = SKShapeNode(circleOfRadius: radius)
        node.fillColor = .randomPastel
        node.position = CGPoint(x: position.x, y: position.y)
        node.name = id.uuidString
        
        representationLabel = SKLabelNode(text: species.speciesRepresentation)
        representationLabel.verticalAlignmentMode = .center
        representationLabel.horizontalAlignmentMode = .center
        representationLabel.name = id.uuidString
//        representationLabel.position = CGPoint(x: node.frame.width / 2, y: node.frame.height / 2)
        
//        sensingNode = SKShapeNode(circleOfRadius: sensoryDistance)
//        sensingNode.strokeColor = .white
//        sensingNode.lineWidth = 5
//
//        node.addChild(sensingNode)
        node.addChild(representationLabel)
    }
    
    // Apply all of the gene changes that have been given to the particular creature.
    func applyGenes() {
        for gene in genes {
            switch gene.effectSpot {
            case .reproductiveAge:
                reproductiveAge += gene.strength
            case .desirability:
                desirability += gene.strength
            case .strength:
                strength += gene.strength
            case .defense:
                defense += gene.strength
            case .sensoryDistance:
                sensoryDistance += gene.strength
            case .speed:
                speed += gene.strength
            }
        }
    }
    
    func randomizeGenes() {
        for gene in genes {
            gene.strength += Random.double(range: -25...25)
        }
    }
    
    // MARK: Position Calculations
    func calculatePositionOnPlanet(allCreatures: ContiguousArray<Creature>, world: ContiguousArray<WorldItem>) {
        nextPosition = position
        randomlySpiceUpNeeds()
        
        var worldItemsInSight: ContiguousArray<WorldItem> = []
        var dangerousCreaturesInSight: ContiguousArray<Creature> = []
        var friendlyCreaturesInSight: ContiguousArray<Creature> = []
        var edibleCreaturesInSight: ContiguousArray<Creature> = []

        for creature in allCreatures {
            if creature.id != id {
                let combinedRadius: Float = Float(creature.radius + sensoryDistance)
                let delta: simd_float2 = simd_float2(Float(creature.position.x - position.x), Float(creature.position.y - position.y))
                let deltaLength: Float = simd_fast_length(delta)
                
                if deltaLength <= combinedRadius {
                    if creature.species.id == self.species.id {
                        friendlyCreaturesInSight.append(creature)
                    } else if creature.species.id != self.species.id {
                        if creature.species.foodChainLevel > self.species.foodChainLevel {
                            // We need to run away
                            dangerousCreaturesInSight.append(creature)
                        } else if creature.species.foodChainLevel < self.species.foodChainLevel {
                            // We can go after the creature if we are hungry
                            edibleCreaturesInSight.append(creature)
                        }
                    }
                }
            }
        }

        for worldItem in world {
            let combinedRadius: Float = Float(worldItem.radius + sensoryDistance)
            let delta: simd_float2 = simd_float2(Float(worldItem.position.x - position.x), Float(worldItem.position.y - position.y))
            let deltaLength: Float = simd_fast_length(delta)
        
            if deltaLength <= combinedRadius {
                worldItemsInSight.append(worldItem)
            }
        }

                
        var currentNeed: CreatureNeed = highestNeed()
        if currentNeed == .any {
            currentNeed = [CreatureNeed.water, CreatureNeed.food, CreatureNeed.reproduce].randomElement()!
        }
        if hunger == 100 {
            beenAtHungerForSteps += 1
            if beenAtHungerForSteps > 15 {
                isEaten = true
            }
        } else {
            beenAtHungerForSteps = 0
        }
        if thirst == 100 {
            beenAtThirstForSteps += 1
            if beenAtThirstForSteps > 15 {
                isEaten = true
            }
        } else {
            beenAtThirstForSteps = 0
        }
        
        // MARK: Decide where to move
        // Top priority is to run from danger
        if dangerousCreaturesInSight.count > 0 {
            let closestDangerousCreature = closestCreature(creatures: dangerousCreaturesInSight)
            runAway(from: closestDangerousCreature)
            return
        } else {
            // Next priority is to fulfill own needs
            if currentNeed == .food {
                if edibleCreaturesInSight.count > 0 {
                    let closestEdibleCreature = closestCreature(creatures: edibleCreaturesInSight)
                    chase(creature: closestEdibleCreature)
                    return
                } else {
                    for worldItem in worldItemsInSight {
                        if worldItem.type == .food && !worldItem.depleted {
                            consume(worldItem: worldItem)
                            return
                        }
                    }
                }
            } else if currentNeed == .water {
                for worldItem in worldItemsInSight {
                    if worldItem.type == .water && !worldItem.depleted {
                        consume(worldItem: worldItem)
                        return
                    }
                }
            } else if currentNeed == .reproduce {
                if friendlyCreaturesInSight.count > 0 {
                    friendlyCreaturesInSight.sort { one, two in
                        return one.desirability > two.desirability
                    }
                    for friendlyCreature in friendlyCreaturesInSight {
                        // Check to see if the creatures are within a desirable range
                        if !friendlyCreature.isInGestation && needToReproduce > 0 {
                            // Select which creature will carry offspring
                            if Random.bool() {
                                // Other Creature
                                friendlyCreature.isInGestation = true
                                friendlyCreature.mate = self
                                friendlyCreature.gestationCounter = 0
                            } else {
                                // This Creature
                                isInGestation = true
                                mate = friendlyCreature
                                gestationCounter = 0
                            }
                            friendlyCreature.needToReproduce = 0
                            needToReproduce = 0
                            return
                        }
                    }
                }
            }
            randomlyMoveInDirection()
        }
    }
    
    // Find the closest creature in an array of creatures
    func closestCreature(creatures: ContiguousArray<Creature>) -> Creature {
        var closest: Creature = creatures.first!
        var closestDistance: Float = Float.greatestFiniteMagnitude
        
        for creature in creatures {
            let distanceToCreature = simd_fast_distance(creature.position.simd, position.simd)
            if closestDistance > distanceToCreature {
                closestDistance = distanceToCreature
                closest = creature
            }
        }
        
        return closest
    }
    
    func randomlySpiceUpNeeds() {
        thirst += Random.double(range: 0...0.02)
        hunger += Random.double(range: 0...0.02)
        needToReproduce += Random.double(range: 0...0.02)
    }
    
    // MARK: Action Functions
    func reproduce() -> Creature? {
        if isInGestation && mate != nil {
            if gestationCounter >= gestationPeriod {
                gestationCounter = 0
                isInGestation = false
                let newCreature = Creature(birthParent: self, givingParent: mate!)
                newCreature.position = self.currentPosition
                newCreature.nextPosition = self.currentPosition
                mate = nil

                return newCreature
            }
            gestationCounter += 1
        }
        return nil
    }

    func highestNeed() -> CreatureNeed {
        if currentlyFulfilling == .none {
            needTimeout = Random.int(range: 200...800)
            needTimeoutCounter = 0
            if needToReproduce > thirst && needToReproduce > hunger {
                currentlyFulfilling = .reproduce
            } else if thirst > needToReproduce && thirst > hunger {
                currentlyFulfilling = .water
            } else if hunger > thirst && hunger > needToReproduce {
                currentlyFulfilling = .food
            } else {
                currentlyFulfilling = .any
            }
        } else {
            if needTimeoutCounter >= needTimeout {
                currentlyFulfilling = .none
            } else {
                needTimeoutCounter += 1
            }
        }
        return currentlyFulfilling
    }
    
    func randomlyMoveInDirection() {
        if moveDirectionCounter >= moveDirectionTime  {
            // We can pick a new direction
            movingDirection = [Direction.positiveX, Direction.positiveY, Direction.negativeX, Direction.negativeY].randomElement()!
            moveDirectionTime = Random.int(range: 1...1000)
            moveDirectionCounter = 0
        } else {
            // We keep moving in the same direction
            switch movingDirection {
            case .positiveX:
                nextPosition.x += Random.double(range: 0...speed)
//                nextPosition.y += Random.double(range:-1...1)
            case .negativeX:
                nextPosition.x += Random.double(range: -speed...0)
//                nextPosition.y += Random.double(range:-1...1)
            case .positiveY:
//                nextPosition.x += Random.double(range: -1...1)
                nextPosition.y += Random.double(range: 0...speed)
            case .negativeY:
//                nextPosition.x += Random.double(range: -1...1)
                nextPosition.y += Random.double(range: 0...speed)
            }
            moveDirectionCounter += 1
        }
    }
    
    func randomMovements(range: ClosedRange<Double>) {
        nextPosition.x += Random.double(range: range)
        nextPosition.y += Random.double(range: range)
    }
    
    func consume(worldItem: WorldItem) {
        let distanceToItem = simd_fast_distance(worldItem.position.simd, position.simd)
        
        // If we are close enough consume the world item
        if distanceToItem < Float(consumeDistance) {
            worldItem.consume(by: self)
        } else {
            // If not, move towards it
            if position.x < worldItem.position.x {
                // We need to move in the positive X
                nextPosition.x += speed
            } else if position.x > worldItem.position.x {
                // We need to move in the negative X
                nextPosition.x -= speed
            }
            
            if position.y < worldItem.position.y {
                // We need to move in the positive Y
                nextPosition.y += speed
            } else if position.y > worldItem.position.y {
                // We need to move in the negative y
                nextPosition.y -= speed
            }
        }
    }
    
    func runAway(from creature: Creature) {
        if creature.position.x < position.x {
            // We need to move in the positive X
            nextPosition.x += speed
        } else if creature.position.x > position.x {
            // We need to move in the negative X
            nextPosition.x -= speed
        }
        
        if creature.position.y < position.y {
            // We need to move in the positive Y
            nextPosition.y += speed
        } else if creature.position.y > position.y {
            // We need to move in the negative y
            nextPosition.y -= speed
        }
        randomMovements(range: -speed...speed)
    }
    
    func chase(creature: Creature) {
        let distanceToItem = simd_fast_distance(creature.position.simd, position.simd)
        if distanceToItem < Float(consumeDistance) {
            creature.isEaten = true
            hunger -= Random.double(range: 10...60)
        } else {
            if position.x < creature.position.x {
                // We need to move in the positive X
                nextPosition.x += speed
            } else if position.x > creature.position.x {
                // We need to move in the negative X
                nextPosition.x -= speed
            }
            
            if position.y < creature.position.y {
                // We need to move in the positive Y
                nextPosition.y += speed
            } else if position.y > creature.position.y {
                // We need to move in the negative y
                nextPosition.y -= speed
            }
        }
    }
    
    func updatePosition() {
        pastStates.append(State(thirst: thirst, hunger: hunger, needToReproduce: needToReproduce, location: position))
        position = nextPosition
    }
    
    func updateNodesForStep(step: Int) {
        if pastStates.count > step {
            let position = pastStates[step].location
            node.position = CGPoint(x: position.x, y: position.y)
            currentPosition = position
        } else {
            Log(level: .Error, "Trying to get creature node for a step (\(step)) that does not exist. \(id.uuidString), totalLocations: \(pastStates.count)")
        }
    }
}

