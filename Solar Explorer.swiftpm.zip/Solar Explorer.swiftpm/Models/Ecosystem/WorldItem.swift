//
//  WorldItem.swift
//  Solar Explorer
//
//  Created by Zachary lineman on 4/13/22.
//

import SpriteKit

// An item in the world. Food or Water
final class WorldItem {
    enum WorldItemType: String {
        case water = "💧"
        case food = "🌱"
    }
    // MARK: Metadata
    var id: UUID = UUID()
    var type: WorldItemType
    var depleted: Bool = false
    var renewalCounter: Double = 0
    var renewalTime: Double = 5000
    
    // MARK: Sprite & Position
    var node: SKShapeNode!
    var representationLabel: SKLabelNode!
    
    var position = CGPoint.zero
    var radius: Double = 20
    
    var pastDepletion: [Bool] = []

    internal init(id: UUID = UUID(), type: WorldItem.WorldItemType, depleted: Bool = false, renewalTime: Double = 60, position: CGPoint = CGPoint.zero) {
        self.id = id
        self.type = type
        self.depleted = depleted
        self.renewalTime = renewalTime
        self.position = position
        setupNodes()
    }

    func setupNodes() {
        node = SKShapeNode(circleOfRadius: radius)
//        node.fillColor = .randomPastel
        node.strokeColor = .clear
        node.position = CGPoint(x: position.x, y: position.y)
        node.name = id.uuidString
        
        representationLabel = SKLabelNode(text: type.rawValue)
        representationLabel.verticalAlignmentMode = .center
        representationLabel.horizontalAlignmentMode = .center
        representationLabel.color = .gray
        representationLabel.colorBlendFactor = 0

        node.addChild(representationLabel)
    }
    
    func update() {
        if depleted {
            if renewalCounter >= renewalTime {
                depleted = false
            } else {
                renewalCounter += 1
            }
        }
        pastDepletion.append(depleted)
    }
    
    func updateNode(for step: Int) {
        if pastDepletion[step] {
            representationLabel.colorBlendFactor = 1
        } else {
            representationLabel.colorBlendFactor = 0
        }
    }
    
    func consume(by creature: Creature) {
        switch type {
        case .water:
            creature.thirst -= Random.double(range: 0...30)
        case .food:
            creature.hunger -= Random.double(range: 0...30)
        }
        representationLabel.colorBlendFactor = 0.8
        depleted = true
    }
}
