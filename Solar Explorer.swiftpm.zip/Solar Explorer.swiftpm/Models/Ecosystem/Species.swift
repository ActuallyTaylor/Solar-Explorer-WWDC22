//
//  Species.swift
//  Solar Explorer
//
//  Created by Zachary lineman.
//

import Foundation

// Represents a singular species of creature.
final class Species {
    var id: UUID = UUID()
    var speciesName: String
    var speciesRepresentation: String
    var reproductionAge: Int
    var foodChainLevel: Int
    var startingGenes: [Gene]
    
    init(speciesName: String, speciesRepresentation: String, reproductionAge: Int, foodChainLevel: Int, startingGenes: [Gene]) {
        self.speciesName = speciesName
        self.speciesRepresentation = speciesRepresentation
        self.reproductionAge = reproductionAge
        self.foodChainLevel = foodChainLevel
        self.startingGenes = startingGenes
    }
}
