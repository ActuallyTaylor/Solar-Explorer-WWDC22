//
//  Gene.swift
//  Solar Explorer
//
//  Created by Zachary lineman.
//

import Foundation

// Represents a gene that can be held by a creature.
final class Gene {    
    var id: UUID = UUID()
    var geneName: String
    var effectSpot: CreatureMetadata
    var strength: Double = 0.0

    internal init(id: UUID = UUID(), geneName: String, effectSpot: CreatureMetadata, strength: Double) {
        self.id = id
        self.geneName = geneName
        self.effectSpot = effectSpot
        self.strength = strength
    }
}
