//
//  Planet.swift
//  Solar Explorer
//
//  Created by Zachary lineman
//

import UIKit
import simd
import SpriteKit


// This class represents a singular planet in the universe. It holds the code to calculate it's position in space, along with the positions of the creatures living upon it.
final class Planet: Copyable {
    // MARK: Universe Values
    var ecosystemStepToPhysicsStepRatio: Int = 10
    var currentUniversePhysicsStep: Int = 0
    var backgroundSimulationEnabled: Bool = false
    var trailLength: Int = 250

    // MARK: Planet Metadata
    var id: UUID = UUID()
    var name: String = ""
    var mass: Double = 10
    var radius: Double = 20
    var color: UIColor!
    var isFutureBody: Bool = false
    var gravitationalConstant: Double = 0.3

    // MARK: Position & Velocity
    var currentPosition: CGPoint = CGPoint.zero
    var currentVelocity: CGVector = CGVector.zero

    var position: simd_double2 = simd_double2(0, 0)
    var velocity: simd_double2 = simd_double2(0, 0)
    
    var cachedLocations: ContiguousArray<CGPoint> = []
    var cachedVelocities: ContiguousArray<CGVector> = []

    // MARK: Sprite Kit
    var node: SKShapeNode  = SKShapeNode()
    var pathNode: SKShapeNode = SKShapeNode()
    
    // MARK: Drawing Options
    var drawPath: Bool = true
    var renderTrailOnly: Bool = false
        
    // MARK: Convenience Variables
    var cgrect: CGRect {
        get {
            return CGRect(x: position.x, y: position.y, width: radius*2, height: radius*2)
        }
    }
    
    var cgpoint: CGPoint {
        get {
            return CGPoint(x: position.x, y: position.y)
        }
    }
    
    // MARK: Ecosystem Simulation Variables
    var needsToSyncEcosystem: Bool = true

    var shouldSimulateEcosystem: Bool = false
    var simulateInBackground: Bool = true
    
    // Storage Arrays
    var creatures: ContiguousArray<Creature> = []
    var world: ContiguousArray<WorldItem> = []

    // Ecosystem Caching
    var currentEcosystemStep = 0
    var currentlyRequesting: Bool = false
    
    // FPS
    var fps: Int = 0
    var frames = 0
    
    // MARK: Initialization
    init() {
        setup()
        populateWithRandomCreatures()
    }
    
    init(position: simd_double2, velocity: simd_double2, mass: Double, allPlanets: [Planet]) {
        self.position = position
        self.velocity = velocity
        self.mass = mass
        self.name = generateRandomPlanetName(allPlanets: allPlanets)
        setup()
        populateWithRandomCreatures()
        dispatchBackgroundUpdates()
    }
    
    required init(model: Planet) {
        self.position = model.position
        self.velocity = model.velocity
        self.mass = model.mass
        self.radius = model.radius
        self.node = model.node
        self.renderTrailOnly = model.renderTrailOnly
        self.cachedLocations = model.cachedLocations
        self.cachedVelocities = model.cachedVelocities
        self.color = model.color
        self.name = model.name
        self.id = model.id
        self.creatures = model.creatures
        self.world = model.world
        setup()
    }
    
    func setup() {
        color = UIColor.randomPastel
        if !isFutureBody {
            node = SKShapeNode(circleOfRadius: radius)
            node.fillColor = color
            node.strokeColor = .clear
            node.name = id.uuidString
            
            pathNode.strokeColor = color
            pathNode.path = createFullPath()
            pathNode.name = "Path \(id.uuidString)"
        }
    }
    
    func redrawNode() {
        node.removeFromParent()
        node = SKShapeNode(circleOfRadius: radius)
        node.fillColor = color
        node.strokeColor = .clear
        node.name = id.uuidString
        node.position = currentPosition
    }
    
    // MARK: Physics Calculations
    func calculateVelocityInSystem(allBodies: [Planet]) {
        for body in allBodies {
            if body != self {
                let distance: Double = simd_fast_distance(position, body.position)
                let directionOfForce: simd_double2 = simd_normalize(body.position - position)
                let force: simd_double2 = directionOfForce * gravitationalConstant * (mass * body.mass) / (distance * distance)
                let acceleration = force / mass
                velocity += acceleration
            }
        }
    }
    
    // Update the position of the planet and place that value into the cache arrays
    func updatePosition() {
        cachedLocations.append(CGPoint(x: position.x, y: position.y))
        cachedVelocities.append(CGVector(dx: velocity.x, dy: velocity.y))
        position += velocity
    }
    
    // Clear out the future calculations in velocity and position.
    func removeAllStepsInFrontOf(step: Int) {
        if cachedVelocities.count > step && cachedLocations.count > step {
            velocity = simd_double2(cachedVelocities[step].dx, cachedVelocities[step].dy)
            position = simd_double2(cachedLocations[step].x, cachedLocations[step].y)
            cachedLocations = ContiguousArray(cachedLocations.prefix(upTo: step))
            cachedVelocities = ContiguousArray(cachedVelocities.prefix(upTo: step))
        }  else {
            Log(level: .Error, "Unable to remove \(step) \(cachedVelocities.count), \(cachedLocations.count) from \(name)")
        }
    }
    
    // Update the display of the nodes to the given step
    func updateNodesForStep(step: Int) {
        if cachedLocations.count > step {
            let position = cachedLocations[step]
            node.position = CGPoint(x: position.x, y: position.y)
            if drawPath {
                pathNode.path = createPath(to: step)
            } else {
                pathNode.path = CGPath(rect: CGRect.zero, transform: .none)
            }
            currentPosition = position
            currentVelocity = cachedVelocities[step]
        } else {
            Log(level: .Error, "Trying to get node for a step (\(step)) that does not exist. \(name), totalLocations: \(cachedLocations.count)")
        }
    }
    
    func createPath(to step: Int) -> CGMutablePath {
        let path = CGMutablePath()
        var position = CGPoint.zero
        position = cachedLocations[step]
        path.move(to: CGPoint(x: position.x, y: position.y))
        
        let locations = cachedLocations.prefix(upTo: step)
        var clampedValue = locations.count - trailLength
        if clampedValue < 0 { clampedValue = 0 }
        let pastArray = locations.reversed().dropLast(clampedValue)
        for point in pastArray {
            path.addLine(to: point)
        }
        
        return path
    }
    
    func createFullPath() -> CGMutablePath {
        let path = CGMutablePath()
        path.move(to: CGPoint(x: position.x, y: position.y))
        
        var clampedValue = cachedLocations.count - 1000
        if clampedValue < 0 { clampedValue = 0 }
        let pastArray = cachedLocations.reversed().dropLast(clampedValue)
        for point in pastArray {
            path.addLine(to: point)
        }
        
        return path
    }

}

// MARK: Equatable Conformence
extension Planet: Equatable {
    static func == (lhs: Planet, rhs: Planet) -> Bool {
        return lhs.id == rhs.id
    }
}

// MARK: Ecosystem Simulation Code
extension Planet {
    // Creates a background utility thread that will run simulation updates to attempt to keep everything in sync.
    func dispatchBackgroundUpdates() {
        if isFutureBody { return }
        if !backgroundSimulationEnabled { return }
        simulateInBackground = true
        Dispatch.utilityTask { [self] in
            Log("Started Background Simulation for \(name)")
            while(simulateInBackground && backgroundSimulationEnabled) {
                if isFutureBody { break }
                if currentEcosystemStep < currentUniversePhysicsStep / ecosystemStepToPhysicsStepRatio {
                    for worldItem in world {
                        worldItem.update()
                    }

                    for creature in creatures {
                        creature.calculatePositionOnPlanet(allCreatures: creatures, world: world)
                    }
                
                    var removeCreatureArray: [UUID] = []
                    for creature in creatures {
                        creature.updatePosition()
                        
                        if creature.isEaten {
                            removeCreatureArray.append(creature.id)
                        } else {
                            let newCreature = creature.reproduce()
                            if let newCreature = newCreature {
                                for _ in 0...currentEcosystemStep {
                                    newCreature.pastStates.append(Creature.State(thirst: 0, hunger: 0, needToReproduce: 0, location: newCreature.currentPosition))
                                }
                                creatures.append(newCreature)
                            }
                        }
                    }
                    if removeCreatureArray.count > 0 {
                        creatures.removeAll { creature in
                            return removeCreatureArray.contains(creature.id)
                        }
                    }
                    
                    currentEcosystemStep += 1
                    frames += 1
                }
            }
            Log("Ended Background Simulation for \(name)")
        }
    }
    
    func leaveExploringPlanet() -> Int {
        shouldSimulateEcosystem = false
        needsToSyncEcosystem = true
        simulateInBackground = true
        dispatchBackgroundUpdates()
        return currentEcosystemStep
    }
    
    func beginExploringPlanet(at step: Int, needToSync: Bool = true) {
        simulateInBackground = false
        if needToSync {
            syncEcosystemStepToPhysicsStep(physicsStep: step)
        }
        shouldSimulateEcosystem = true
    }
    
    // Sync up the entire ecosystem to the given physics step. This ensures that he universe stays in sync.
    func syncEcosystemStepToPhysicsStep(physicsStep: Int) {
        if needsToSyncEcosystem {
            Log("Syncing \(name) - Current: \(currentEcosystemStep), Physics: \(physicsStep)")
            if currentEcosystemStep < physicsStep {
                Log(level: .Working, "Fast forwarding ecosystem on \(name) to match physics step \(physicsStep)")
                while(currentEcosystemStep <= physicsStep) {
                    for creature in creatures {
                        creature.calculatePositionOnPlanet(allCreatures: creatures, world: world)
                    }
                    for creature in creatures {
                        creature.updatePosition()
                    }
                    currentEcosystemStep += 1
                }
            } else if currentEcosystemStep > physicsStep {
                Log(level: .Working, "Re-winding ecosystem on \(name) to match physics step \(physicsStep)")
                for creature in creatures {
                    if physicsStep == 0 {
                        creature.position = cachedLocations[physicsStep]
                        creature.updateNodesForStep(step: physicsStep)
                        cachedLocations = ContiguousArray(cachedLocations.prefix(upTo: physicsStep))
                    }
                }
                currentEcosystemStep = physicsStep
            }
            needsToSyncEcosystem = false
            Log(level: .Success, "Done syncing \(name) to step \(physicsStep)")
        }
    }
        
    func updateEcosystem() {
        if shouldSimulateEcosystem {
            for worldItem in world {
                worldItem.update()
            }

            for creature in creatures {
                creature.calculatePositionOnPlanet(allCreatures: self.creatures, world: self.world)
            }
        
            var removeCreatureArray: [UUID] = []
            var addedCreature: Bool = false
            for creature in creatures {
                creature.updatePosition()
                creature.updateNodesForStep(step: currentEcosystemStep)

                if creature.isEaten {
                    removeCreatureArray.append(creature.id)
                } else {
                    let newCreature = creature.reproduce()
                    if let newCreature = newCreature {
                        for _ in 0...currentEcosystemStep {
                            newCreature.pastStates.append(Creature.State(thirst: 0, hunger: 0, needToReproduce: 0, location: newCreature.currentPosition))
                        }
                        addedCreature = true
                        creatures.append(newCreature)
                    }
                }
            }
            if removeCreatureArray.count > 0 {
                creatures.removeAll { creature in
                    if removeCreatureArray.contains(creature.id) {
                        creature.node.removeFromParent()
                        return true
                    }
                    return false
                }
            }
            if addedCreature {
                NotificationCenter.default.post(name: .planetAddedCreature, object: nil)
            }
            
            currentEcosystemStep += 1
            frames += 1
        }
    }
}

// MARK: Random Generation
extension Planet {
    // Generate a random genome for each creature
    func generateRandomGenes() -> [Gene] {
        var genes: [Gene] = []
        
        let randomGenomeCount = Random.int(range: 5...15)
        for _ in 0..<randomGenomeCount {
            let value = Random.double(range: -100...100)
            
            let possibleTraits: [CreatureMetadata] = [.speed, .strength, .sensoryDistance, .defense, .desirability, .reproductiveAge]
            let randomTraitIndex = Random.int(range: 0..<possibleTraits.count)

            let traitType: CreatureMetadata = possibleTraits[randomTraitIndex]
                        
            let gene = Gene(geneName: "", effectSpot: traitType, strength: value)
            genes.append(gene)
        }
        
        return genes
    }
    
    // Generate a random number of species with random genomes
    func generateRandomSpecies() -> [Species] {
        var species: [Species] = []

        let speciesDictionary: [(String, String)] = [("Dog", "🐶"), ("Cat", "🐱"), ("Mouse", "🐭"), ("Hamster", "🐹"), ("Rabbit", "🐰"), ("Fox", "🦊"), ("Bear", "🐻"), ("Panda", "🐼"), ("Polar Bear", "🐻‍❄️"), ("Koala", "🐨"), ("Tiger", "🐯"), ("Lion", "🦁"), ("Cow", "🐮"), ("Pig", "🐷"), ("Frog", "🐸"), ("Monkey", "🐵"), ("Chicken", "🐔"), ("Penguin", "🐧"), ("Bird", "🐦"), ("Chick", "🐤"), ("Dragon", "🐲"), ("Unicorn", "🦄"), ("Butterfly", "🦋"), ("Octopus", "🐙"), ("Snake", "🐍"), ("Bee", "🐝"), ("Whale", "🐳"), ("Crab", "🦀"), ("Horse", "🐴"), ("Wolf", "🐺"), ("Boar", "🐗"), ("Owl", "🦉"), ("Caterpillar", "🐛"), ("Ladybug", "🐞")]
        let randomSpeciesCount = Random.int(range: 2...15)
        
        for _ in 0..<randomSpeciesCount {
            let randomSpecies = speciesDictionary[Random.int(range: 0..<speciesDictionary.count)]
            let genes = generateRandomGenes()
            species.append(Species(speciesName: randomSpecies.0, speciesRepresentation: randomSpecies.1, reproductionAge: Random.int(range: 1..<15), foodChainLevel: Random.int(range: 0..<randomSpeciesCount), startingGenes: genes))
        }
        
        return species
    }
    
    // Generate random deposits of food and water
    func generateRandomFoodAndWater() {
        let randomDepositCount = Random.int(range: 50...75)
        
        for _ in 0..<randomDepositCount {
            let randomItemCount = Random.int(range: 5...15)
            let randomSpeciesDispersion = Random.double(range: 100...400)
            let speciesSpawnX = Random.double(range: -2000...2000)
            let speciesSpawnY = Random.double(range: -2000...2000)
            let depositType: WorldItem.WorldItemType = [WorldItem.WorldItemType.food, WorldItem.WorldItemType.water].randomElement()!
            for _ in 0..<randomItemCount {
                let worldItem = WorldItem(type: depositType, position: CGPoint(x: speciesSpawnX + Random.double(range: -randomSpeciesDispersion...randomSpeciesDispersion), y: speciesSpawnY + Random.double(range: -randomSpeciesDispersion...randomSpeciesDispersion)))
                world.append(worldItem)
            }
        }

    }
    
    // Populate the world with a random amount of creatures and then populate the world with food and water.
    func populateWithRandomCreatures() {
        Log(level: .Working, "Creating world for \(name), ")
        generateRandomFoodAndWater()

        Log(level: .Working, "Populating \(name), with creatures")
        let planetSpecies: [Species] = generateRandomSpecies()

        for n in 0..<planetSpecies.count {
            let randomCreatureAmount = Random.int(range: 5...20)
            let speciesSpawnX = Random.double(range: -1000...1000)
            let speciesSpawnY = Random.double(range: -1000...1000)
            for _ in 0..<randomCreatureAmount {
                let creature = Creature(species: planetSpecies[n])
                creature.randomizeGenes()
                creature.position = CGPoint(x: speciesSpawnX + Random.double(range: -200...200), y: speciesSpawnY + Random.double(range: -200...200))
                creatures.append(creature)
            }
        }
        Log(level: .Success, "Created \(creatures.count) creatures")
    }

}
