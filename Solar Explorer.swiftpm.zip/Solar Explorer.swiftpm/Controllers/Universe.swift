//
//  Universe.swift
//  Solar Explorer
//
//  Created by Zachary lineman
//

import SwiftUI
import simd
import SpriteKit

// This object controls everything that is happening.
class Universe: ObservableObject {
    // MARK: Constants
    var ecosystemStepToPhysicsStepRatio: Int = 10 {
        didSet {
            for body in bodies {
                body.ecosystemStepToPhysicsStepRatio = ecosystemStepToPhysicsStepRatio
            }
        }
    }
    var trailLength: Int = 250 {
        didSet {
            for body in bodies {
                body.trailLength = trailLength
            }
        }
    }
    
    // MARK: SceneKit Scene References
    var mainScene: PlanetScene!
    var ecosystemScene: EcosystemScene!
    var waitingScene: WaitingScene!

    // MARK: Scene Display Variables
    var waitingForSync: Bool = false
    var planetSceneIsPaused: Bool = false
    var ecosystemSceneIsPaused: Bool = true
    var shouldShowSettings: Bool = false

    // MARK: Planetary Simulation Settings
    var hasShownEditorHelp: Bool = false
    @Published var planetSimRunning: Bool = false
    @Published var isEditingPlanet: Bool = false {
        didSet {
            if !hasShownEditorHelp {
                HelpController.shared.currentHelpView = HelpController.shared.editorTags[0]
                hasShownEditorHelp = true
            }
        }
    }
    @Published var shouldShowTrails: Bool = true {
        didSet {
            for body in bodies {
                body.drawPath = shouldShowTrails
            }
        }
    }
    
    // MARK: UI Variables
    @Published var shouldShowPlanetOverlay: Bool = false
    @Published var shouldShowPlanetTool: Bool = false
    @Published var shouldShowStats: Bool = false
    @Published var shouldShowBodiesPanel: Bool = false
    
    // MARK: FPS
    @Published var fps: Int = 0
    var frames = 0

    // MARK: Physics Caching
    var currentPhysicsStep = 0
    var futurePhysicsCalculation: Int = 500
    var farthestCalculation = 0
    var currentlyRequesting: Bool = false

    // MARK: Starting Bodies
    var bodies: [Planet] = [
        Planet(position: simd_double2(300,300), velocity: simd_double2(0,1.5), mass: 20, allPlanets: []),
        Planet(position: simd_double2(-300,-300), velocity: simd_double2(0,-1.5), mass: 20, allPlanets: []),
        Planet(position: simd_double2(300,-300), velocity: simd_double2(0,1.5), mass: 20, allPlanets: []),
        Planet(position: simd_double2(-300,300), velocity: simd_double2(0,-1.5), mass: 20, allPlanets: []),
        Planet(position: simd_double2(0, 0), velocity: simd_double2(0,0.1), mass: 15000, allPlanets: [])
    ]
    
    // MARK: Planet Editing
    var editingPlanetIndex: Int = 0
    @Published var editingPlanetName: String = ""
    @Published var editingPlanetVelocityX: Double = 0.0
    @Published var editingPlanetVelocityY: Double = 0.0
    @Published var editingPlanetMass: Double = 0.0
    @Published var editingPlanetRadius: Double = 0.0
    var editingPlanetUUIDString: String = ""

    // Cached Planet Values
    var savedPlanetName: String = ""
    var savedPlanetVelocityX: Double = 0.0
    var savedPlanetVelocityY: Double = 0.0
    var savedPlanetMass: Double = 0.0
    var savedPlanetRadius: Double = 0.0

    var preEditingPlanetSimRunning = false
    var isAddingPlanet = false
    
    // MARK: Planet Ecosystems
    var currentlyExploring: Bool = false
    var currentlyExploringPlanet: Planet!
    
    var shouldSimulateEcosystemsInBackground: Bool = false {
        didSet {
            for planet in bodies {
                planet.backgroundSimulationEnabled = shouldSimulateEcosystemsInBackground
                if shouldSimulateEcosystemsInBackground {
                    planet.dispatchBackgroundUpdates()
                }
            }
        }
    }
    var syncToIndex: Int = 0

    init() {
        calculateNextFrames()
        
        for body in bodies {
            body.drawPath = shouldShowTrails
            body.updateNodesForStep(step: 1)
        }
        
        // Create timers to update physics and FPS calculations
        _ = Timer.scheduledTimer(timeInterval: 0.01, target: self, selector: #selector(updateUniverse), userInfo: nil, repeats: true)
        _ = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(physicsFrameCalculation), userInfo: nil, repeats: true)
    }
    
    func resetSim() {
        currentPhysicsStep = 0
        mainScene.removeChildren(in: bodies.map({$0.node}))
        mainScene.removeChildren(in: bodies.map({$0.pathNode}))
        mainScene.futureSimulationNode.removeAllChildren()
        
        bodies = [
            Planet(position: simd_double2(300,300), velocity: simd_double2(0,1.5), mass: 20, allPlanets: []),
            Planet(position: simd_double2(-300,-300), velocity: simd_double2(0,-1.5), mass: 20, allPlanets: []),
            Planet(position: simd_double2(300,-300), velocity: simd_double2(0,1.5), mass: 20, allPlanets: []),
            Planet(position: simd_double2(-300,300), velocity: simd_double2(0,-1.5), mass: 20, allPlanets: []),
            Planet(position: simd_double2(0, 0), velocity: simd_double2(0,0.1), mass: 15000, allPlanets: [])
        ]
        
        for body in bodies {
            body.drawPath = shouldShowTrails
            body.updateNodesForStep(step: 1)
        }

        
        currentPhysicsStep = 0
        farthestCalculation = 0
        calculateNextFrames()
        planetSimRunning = true
        mainScene.focusToPlanet(bodies[4])
        NotificationCenter.default.post(Notification(name: .simulationReset, object: nil))
    }
    
    func totalElementCount() -> Int {
        var count = 0
        if !planetSceneIsPaused {
            guard let mainScene = mainScene else { return 0 }
            for node in mainScene.children {
                count += 1
                count += countChildren(node: node)
            }
        } else {
            guard let ecoScene = ecosystemScene else { return 0 }
            for node in ecoScene.children {
                count += 1
                count += countChildren(node: node)
            }
        }
        
        return count
    }
    
    func countChildren(node: SKNode) -> Int {
        if node.children.count > 0 {
            return 0
        } else {
            var count = 0
            for item in node.children {
                count += 1
                count += countChildren(node: item)
            }
            return count
        }
    }
    
    // Syncs all of the planet positions to the current physcis step. Used when returning from an on planet simulation
    func syncEntireUniverse(to step: Int, startBody: Planet) {
        if currentPhysicsStep < step {
            Log(level: .Working, "Fast forwarding universe to match physics step \(step)")
            while(currentPhysicsStep <= step) {
                for body in bodies {
                    body.calculateVelocityInSystem(allBodies: bodies)
                }
                for body in bodies {
                    body.updatePosition()
                }
                
                currentPhysicsStep += 1
                farthestCalculation += 1
            }
            calculateNextFrames()
        } else if currentPhysicsStep > step {
            Log(level: .Working, "Re-winding universe to match physics step \(step)")
            for body in bodies {
                body.removeAllStepsInFrontOf(step: step)
            }
            currentPhysicsStep = step
            farthestCalculation = step
            calculateNextFrames()
        }
        for body in bodies {
            body.updateNodesForStep(step: currentPhysicsStep)
        }
        Log(level: .Success, "Done Syncing Universe")
    }
        
    @objc func updateUniverse() {
        if !planetSceneIsPaused {
            updatePhysics()
        }
        if !ecosystemSceneIsPaused {
            if currentlyExploringPlanet == nil { return }
            currentlyExploringPlanet.updateEcosystem()
        }
    }
}

// MARK: Physics
extension Universe {
    @objc func calculateNextFrames() {
        for _ in 0..<1000 {
            for body in bodies {
                body.calculateVelocityInSystem(allBodies: bodies)
            }
            for body in bodies {
                body.updatePosition()
            }
            farthestCalculation += 1
        }
        currentlyRequesting = false
    }
    
    @objc func updatePhysics() {
        if planetSimRunning {
            for body in bodies {
                body.updateNodesForStep(step: currentPhysicsStep)
                body.currentUniversePhysicsStep = currentPhysicsStep
            }
            currentPhysicsStep += 1
            frames += 1
        }
        if currentPhysicsStep + 500 >= farthestCalculation && !currentlyRequesting {
            currentlyRequesting = true
            calculateNextFrames()
        }
    }
    
    @objc func physicsFrameCalculation() {
        if !planetSceneIsPaused {
            fps = frames
            frames = 0
        } else {
            fps = currentlyExploringPlanet.frames
            currentlyExploringPlanet.frames = 0
        }
    }

    // MARK: Functions for generating future paths
    func resetFuturePhysics() {
        mainScene.futureSimulationNode.removeAllChildren()
    }
    
    // Simulates a bodies future steps. Used when editing or creating a new planet to show the path of trajectory.
    func simulatePhysicsIntoFuture(steps: Int) {
        if isEditingPlanet {
            let fakeBodies: [Planet] = bodies.map({$0.copy()})
            
            for body in fakeBodies {
                body.isFutureBody = true
                if body.cachedLocations.count > currentPhysicsStep {
                    let location = body.cachedLocations[currentPhysicsStep]
                    body.position = simd_double2(x: location.x, y: location.y)
                    let velocity = body.cachedVelocities[currentPhysicsStep]
                    body.velocity = simd_double2(x: velocity.dx, y: velocity.dy)
                }
                body.removeAllStepsInFrontOf(step: currentPhysicsStep)
                body.node = SKShapeNode()
                body.pathNode = SKShapeNode()
            }
            
            for _ in 0..<steps {
                for body in fakeBodies {
                    body.calculateVelocityInSystem(allBodies: fakeBodies)
                }
                for body in fakeBodies {
                    body.updatePosition()
                }
            }
            
            if let planet = fakeBodies.first(where: { planet in return planet.id.uuidString == editingPlanetUUIDString }) {
                let path = SKShapeNode()
                path.name = "Simulation Path"
                path.path = planet.createFullPath()
                mainScene.futureSimulationNode.addChild(path)
            }
        }
    }
}

// MARK: Planet Editing & Creation
extension Universe {
    func addPlanet(location: CGPoint) {
        preEditingPlanetSimRunning = planetSimRunning
        isEditingPlanet = true
        
        let body = Planet(position: simd_double2(location.x, location.y), velocity: simd_double2(0,0), mass: 20, allPlanets: bodies)
        
        // We have to fill the past locations and past velocities array to the same capacity as the rest of the bodies so that they will not fall out of sync.
        for _ in 0...currentPhysicsStep {
            body.cachedLocations.append(CGPoint(x: location.x, y: location.y))
            body.cachedVelocities.append(CGVector.zero)
        }
        
        bodies.append(body)
        editingPlanetIndex = bodies.firstIndex(of: body) ?? bodies.count - 1
        bodies[editingPlanetIndex].node.position = CGPoint(x: body.position.x, y: body.position.y)
        
        editingPlanetName = bodies[editingPlanetIndex].name
        editingPlanetVelocityX = bodies[editingPlanetIndex].velocity.x
        editingPlanetVelocityY = bodies[editingPlanetIndex].velocity.y
        editingPlanetMass = bodies[editingPlanetIndex].mass
        editingPlanetRadius = bodies[editingPlanetIndex].radius
        editingPlanetUUIDString = bodies[editingPlanetIndex].id.uuidString
        
        savedPlanetName = bodies[editingPlanetIndex].name
        savedPlanetVelocityX = bodies[editingPlanetIndex].velocity.x
        savedPlanetVelocityY = bodies[editingPlanetIndex].velocity.y
        savedPlanetMass = bodies[editingPlanetIndex].mass
        savedPlanetRadius = bodies[editingPlanetIndex].radius
        
        isAddingPlanet = true
        
        withAnimation {
            shouldShowPlanetTool = true
            planetSimRunning = false
        }

    }
    
    func editPlanet(index: Int) {
        preEditingPlanetSimRunning = planetSimRunning
        isEditingPlanet = true

        editingPlanetIndex = index
        
        editingPlanetName = bodies[editingPlanetIndex].name
        editingPlanetVelocityX = bodies[editingPlanetIndex].cachedVelocities[currentPhysicsStep].dx
        editingPlanetVelocityY = bodies[editingPlanetIndex].cachedVelocities[currentPhysicsStep].dy
        editingPlanetMass = bodies[editingPlanetIndex].mass
        editingPlanetRadius = bodies[editingPlanetIndex].radius
        editingPlanetUUIDString = bodies[editingPlanetIndex].id.uuidString
        
        savedPlanetName = bodies[editingPlanetIndex].name
        savedPlanetVelocityX = bodies[editingPlanetIndex].cachedVelocities[currentPhysicsStep].dx
        savedPlanetVelocityY = bodies[editingPlanetIndex].cachedVelocities[currentPhysicsStep].dy
        savedPlanetMass = bodies[editingPlanetIndex].mass
        savedPlanetRadius = bodies[editingPlanetIndex].radius
        
        isAddingPlanet = false

        withAnimation {
            planetSimRunning = false
            shouldShowPlanetTool = true
        }
    }
    
    func updateEditingPlanetData() {
        if isEditingPlanet {
            bodies[editingPlanetIndex].name = editingPlanetName
            bodies[editingPlanetIndex].mass = editingPlanetMass
            bodies[editingPlanetIndex].radius = editingPlanetRadius
            bodies[editingPlanetIndex].cachedVelocities[currentPhysicsStep] = CGVector(dx: editingPlanetVelocityX, dy: editingPlanetVelocityY)

            if bodies[editingPlanetIndex].node.parent != nil {
                if bodies[editingPlanetIndex].currentPosition == CGPoint.zero {
                    bodies[editingPlanetIndex].currentPosition = CGPoint(x: bodies[editingPlanetIndex].position.x, y: bodies[editingPlanetIndex].position.y)
                }
                bodies[editingPlanetIndex].redrawNode()
                mainScene.addChild(bodies[editingPlanetIndex].node)
            }
        }
    }
    
    func submitPlanetUpdates() {
        isEditingPlanet = false
        
        withAnimation {
            shouldShowPlanetTool = false
        }
        
        editingPlanetName = ""
        editingPlanetVelocityX = 0
        editingPlanetVelocityY = 0
        editingPlanetMass = 0
        editingPlanetRadius = 0
        
        resetFuturePhysics()

        for body in bodies {
            body.removeAllStepsInFrontOf(step: currentPhysicsStep)
        }
        farthestCalculation = currentPhysicsStep
        calculateNextFrames()
        
        planetSimRunning = preEditingPlanetSimRunning
    }
    
    func deletePlanet() {
        isEditingPlanet = false
        bodies[editingPlanetIndex].node.removeFromParent()
        bodies[editingPlanetIndex].pathNode.removeFromParent()
        bodies.remove(at: editingPlanetIndex)
        
        withAnimation {
            shouldShowPlanetTool = false
        }
        isAddingPlanet = false
        
        editingPlanetName = ""
        editingPlanetVelocityX = 0
        editingPlanetVelocityY = 0
        editingPlanetMass = 0
        editingPlanetRadius = 0
        
        resetFuturePhysics()
        for body in bodies {
            body.removeAllStepsInFrontOf(step: currentPhysicsStep)
        }
        farthestCalculation = currentPhysicsStep
        calculateNextFrames()

        planetSimRunning = preEditingPlanetSimRunning
    }
    
    func cancelPlanet() {
        isEditingPlanet = false
        withAnimation {
            shouldShowPlanetTool = false
        }
        
        bodies[editingPlanetIndex].name = savedPlanetName
        bodies[editingPlanetIndex].velocity.x = savedPlanetVelocityX
        bodies[editingPlanetIndex].velocity.y = editingPlanetVelocityY
        bodies[editingPlanetIndex].mass = editingPlanetMass
        bodies[editingPlanetIndex].radius = editingPlanetRadius

        editingPlanetName = ""
        editingPlanetVelocityX = 0
        editingPlanetVelocityY = 0
        editingPlanetMass = 0
        editingPlanetRadius = 0
        editingPlanetIndex = 0
        
        resetFuturePhysics()
        planetSimRunning = preEditingPlanetSimRunning
    }
}

// MARK: Planet Exploration
extension Universe {
    func explore(planet: Planet, needToSync: Bool = true) {
        planetSceneIsPaused = false
        let equivalentEcosystemStep = currentPhysicsStep / 10
        if planet.needsToSyncEcosystem && planet.currentEcosystemStep != equivalentEcosystemStep {
            planet.simulateInBackground = false
            waitingScene.stepToSyncTo = currentPhysicsStep
            waitingScene.waitingForPlanet = planet
            waitingForSync = true
            
            Dispatch.delay(seconds: 1) {
                Dispatch.background {
                    planet.syncEcosystemStepToPhysicsStep(physicsStep: equivalentEcosystemStep)
                }
            }
        } else {
            planet.simulateInBackground = false
            planetSceneIsPaused = true
            ecosystemSceneIsPaused = false
            ecosystemScene.updateSceneForPlanet(planet: planet)
            currentlyExploringPlanet = planet
            withAnimation(.easeInOut(duration: 1.0)) {
                currentlyExploring = true
            }
            planet.beginExploringPlanet(at: equivalentEcosystemStep, needToSync: needToSync)
        }
    }
    
    func stopExploring() {
        ecosystemScene.isFocusingCreature = false
        ecosystemScene.focusingCreatureUUID = ""
        ecosystemScene.fadeOut(node: ecosystemScene.focusNode)
        planetSceneIsPaused = false
        ecosystemSceneIsPaused = true
        currentlyExploring = false
        guard let planet = currentlyExploringPlanet else { return }
        let stepToSyncTo = planet.leaveExploringPlanet() * 10
        
        syncEntireUniverse(to: stepToSyncTo, startBody: planet)
    }
}
