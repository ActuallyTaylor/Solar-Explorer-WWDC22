//
//  HelpController.swift
//  Solar Explorer
//
//  Created by Zachary lineman.
//

import SwiftUI

// Manages all of the help instructions
class HelpController: ObservableObject {
    enum HelpTrack {
        case starting
        case editor
    }
    
    static let shared: HelpController = HelpController()
    
    var currentStartingIndex: Int = 0
    var currentEditorIndex: Int = 0

    var startingTags: [String] = ["Start", "Control Strip", "Click Planet"]
    var editorTags: [String] = ["Name", "Velocity", "Mass", "Radius"]
    @Published var currentHelpView: String = "Start"
    
    private init() { }
    
    func advanceHelpView(track: HelpTrack) {
        if track == .starting {
            currentStartingIndex += 1
            if currentStartingIndex < startingTags.count {
                withAnimation {
                    currentHelpView = startingTags[currentStartingIndex]
                }
            } else {
                currentStartingIndex = 0
                withAnimation {
                    currentHelpView = "Nil"
                }
            }
        } else if track == .editor {
            currentEditorIndex += 1
            if currentEditorIndex < editorTags.count {
                withAnimation {
                    currentHelpView = editorTags[currentEditorIndex]
                }
            } else {
                currentEditorIndex = 0
                withAnimation {
                    currentHelpView = "Nil"
                }
            }
        }
    }
    
    func isEnabled(_ id: String) -> Bool {
        return currentHelpView == id
    }
}
