//
//  Notifications.swift
//  Solar Explorer
//
//  Created by Zachary lineman
//

import SwiftUI

// An extension that allows for easier use Notifications.
extension Notification.Name {
    static let gravitationalConstantChanged = Notification.Name("GravitationalConstantChanged")
    static let simulationReset = Notification.Name("reset")
    static let trailsChanged = Notification.Name("trails")
    static let trackedPlanetPositionChanged = Notification.Name("trackedPlanetPositionChanged")
    static let planetAddedCreature = Notification.Name("planetAddedCreature")
}
