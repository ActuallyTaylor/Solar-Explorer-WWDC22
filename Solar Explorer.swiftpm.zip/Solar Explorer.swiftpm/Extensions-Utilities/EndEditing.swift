//
//  EndEditing.swift
//  Solar Explorer
//
//  Created by Zachary lineman
//

import UIKit

// An extension that will stop editing across the view.
extension UIApplication {
    func endEditing() {
        sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
    }
}
