//
//  ColorExtensions.swift
//  Solar Explorer
//
//  Created by Zachary lineman
//

import UIKit

// Extension that will give random colors.
extension UIColor {
    static var random: UIColor {
        get {
            let hue = CGFloat.random(in: 0...1)
            let saturation = CGFloat.random(in: 0...1)
            let brightness = CGFloat.random(in: 0...1)
            
            return UIColor(hue: hue, saturation: saturation, brightness: brightness, alpha: 1.0)
        }
    }
    
    static var randomPastel: UIColor {
        get {
            let hue = CGFloat.random(in: 0.5...1)
            let saturation = CGFloat.random(in: 0.25...0.50)
            let brightness = 1.0//CGFloat.random(in: 0...1)
            
            return UIColor(hue: hue, saturation: saturation, brightness: brightness, alpha: 1.0)
        }
    }

}
