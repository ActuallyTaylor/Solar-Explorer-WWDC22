//
//  Clamped.swift
//  Solar Explorer
//
//  Created by Zachary lineman.
//

import Foundation

// https://stackoverflow.com/questions/36110620/standard-way-to-clamp-a-number-between-two-values-in-swift
extension Comparable {
    func clamped(to limits: ClosedRange<Self>) -> Self {
        return min(max(self, limits.lowerBound), limits.upperBound)
    }
}
