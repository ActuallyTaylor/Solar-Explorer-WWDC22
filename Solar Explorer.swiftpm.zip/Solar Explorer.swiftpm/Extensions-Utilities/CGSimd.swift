//
//  CGSimd.swift
//  Solar Explorer
//
//  Created by Zachary lineman.
//

import CoreGraphics
import simd

// An extension to get an SIMD_FLOAT2 from a CGPoint
extension CGPoint {
    var simd: simd_float2 {
        get {
            return simd_float2(x: Float(x), y: Float(y))
        }
    }
}
