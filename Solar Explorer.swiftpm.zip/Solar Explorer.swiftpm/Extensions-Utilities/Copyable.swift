//
//  Copyable.swift
//  Solar Explorer
//
//  Created by https://stackoverflow.com/questions/27812433/how-do-i-make-a-exact-duplicate-copy-of-an-array
//

import SwiftUI

// A protocol that allows a class to be copyable.
protocol Copyable {
    init(model: Self)
}

extension Copyable {
    func copy() -> Self {
        return Self.init(model: self)
    }
}
